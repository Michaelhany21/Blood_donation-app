import 'package:flutter/material.dart';
import 'package:soul_saver/core/app_export.dart';

class AppStyle {
  static TextStyle txtMontserratRegular9 = TextStyle(
    color: ColorConstant.gray500,
    fontSize: getFontSize(
      9,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtMontserratRegular7 = TextStyle(
    color: ColorConstant.gray600,
    fontSize: getFontSize(
      7,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtMontserratRegular8 = TextStyle(
    color: ColorConstant.gray600,
    fontSize: getFontSize(
      8,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtMontserratSemiBold12Gray800 = TextStyle(
    color: ColorConstant.gray800,
    fontSize: getFontSize(
      12,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w600,
  );

  static TextStyle txtMontserratRegular8Red800 = TextStyle(
    color: ColorConstant.red800,
    fontSize: getFontSize(
      8,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtMontserratRegular13Black900 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      13,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtMontserratSemiBold14 = TextStyle(
    color: ColorConstant.red800,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w600,
  );

  static TextStyle txtMontserratSemiBold12 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      12,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w600,
  );

  static TextStyle txtMontserratBold18 = TextStyle(
    color: ColorConstant.blueGray900,
    fontSize: getFontSize(
      18,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtMontserratSemiBold14Black900 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w600,
  );

  static TextStyle txtSegoeUI14 = TextStyle(
    color: ColorConstant.blueGray900,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Segoe UI',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtMontserratRegular14 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtPoppinsMedium15Gray90001 = TextStyle(
    color: ColorConstant.gray90001,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtMontserratRegular12 = TextStyle(
    color: ColorConstant.gray500,
    fontSize: getFontSize(
      12,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtMontserratBold20Bluegray900 = TextStyle(
    color: ColorConstant.blueGray900,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtMontserratRegular13 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      13,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtMontserratBold40 = TextStyle(
    color: ColorConstant.red800,
    fontSize: getFontSize(
      40,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtRobotoRegular20 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtPoppinsMedium15 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtMontserratRegular13Black9001 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      13,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtMontserratBold24 = TextStyle(
    color: ColorConstant.red800,
    fontSize: getFontSize(
      24,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtMontserratRegular12Gray800 = TextStyle(
    color: ColorConstant.gray800,
    fontSize: getFontSize(
      12,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtMontserratMedium14 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtMontserratBold20 = TextStyle(
    color: ColorConstant.whiteA70001,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtMontserratMedium16 = TextStyle(
    color: ColorConstant.gray800,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtMontserratRegular14Gray500 = TextStyle(
    color: ColorConstant.gray500,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtMontserratRegular10 = TextStyle(
    color: ColorConstant.gray900,
    fontSize: getFontSize(
      10,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtMontserratRegular14Gray800 = TextStyle(
    color: ColorConstant.gray800,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtMontserratRomanRegular17 = TextStyle(
    color: ColorConstant.red800,
    fontSize: getFontSize(
      17,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtMontserratSemiBold8Red800 = TextStyle(
    color: ColorConstant.red800,
    fontSize: getFontSize(
      8,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w600,
  );

  static TextStyle txtMontserratSemiBold20 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w600,
  );

  static TextStyle txtDMSansMedium15 = TextStyle(
    color: ColorConstant.gray90001,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'DM Sans',
    fontWeight: FontWeight.w500,
  );

  static TextStyle txtMontserratSemiBold8 = TextStyle(
    color: ColorConstant.gray600,
    fontSize: getFontSize(
      8,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w600,
  );

  static TextStyle txtRobotoRegular16 = TextStyle(
    color: ColorConstant.bluegray400,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtMontserratBold20WhiteA700 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtMontserratRegular24 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      24,
    ),
    fontFamily: 'Montserrat',
    fontWeight: FontWeight.w400,
  );
}
