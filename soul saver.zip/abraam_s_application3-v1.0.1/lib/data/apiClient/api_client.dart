import 'package:soul_saver/core/app_export.dart';

class ApiClient extends GetConnect {}
