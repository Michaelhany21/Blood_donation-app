class CompatibilityChartModel {}
