import 'package:flutter/material.dart';

class CompatibilityPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:
      Column(
        children: [
          PreferredSize(
            preferredSize: Size.fromHeight(56.0),
            child: AppBar(
              leading: IconButton(
                icon: Icon(
                  Icons.arrow_back_ios_new_outlined,
                  color: Colors.red,
                  size: 30.0,
                ),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
              title: Text(
                'Blood Type Compatibility',
                style: TextStyle(
                  fontFamily: 'txtMontserratRegular',
                  fontSize: 20.0,
                  color: Colors.red[800],
                ),
              ),
              backgroundColor: Colors.white,
              iconTheme: IconThemeData(color: Colors.red),
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              child: Container(
                margin: EdgeInsets.all(16.0),
                child: DataTable(
                  headingTextStyle: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                  dataTextStyle: TextStyle(
                    color: Colors.black87,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(
                      color: Colors.red,
                      width: 1.0,
                    ),
                    borderRadius: BorderRadius.circular(15.0),
                  ),
                  columns: const <DataColumn>[
                    DataColumn(
                      label: Text('Blood Type'),
                    ),
                    DataColumn(
                      label: Text('Can Donate To'),
                    ),
                  ],
                  rows: const <DataRow>[
                    DataRow(
                      cells: <DataCell>[
                        DataCell(Text('A+')),
                        DataCell(Text('A+, AB+')),
                      ],
                    ),
                    DataRow(
                      cells: <DataCell>[
                        DataCell(Text('A-')),
                        DataCell(Text('A+, A-, AB+, AB-')),
                      ],
                    ),
                    DataRow(
                      cells: <DataCell>[
                        DataCell(Text('B+')),
                        DataCell(Text('B+, AB+')),
                      ],
                    ),
                    DataRow(
                      cells: <DataCell>[
                        DataCell(Text('B-')),
                        DataCell(Text('B+, B-, AB+, AB-')),
                      ],
                    ),
                    DataRow(
                      cells: <DataCell>[
                        DataCell(Text('AB+')),
                        DataCell(Text('AB+')),
                      ],
                    ),
                    DataRow(
                      cells: <DataCell>[
                        DataCell(Text('AB-')),
                        DataCell(Text('A-, B-, AB-, O-')),
                      ],
                    ),
                    DataRow(
                      cells: <DataCell>[
                        DataCell(Text('O+')),
                        DataCell(Text('A+, B+, AB+, O+')),
                      ],
                    ),
                    DataRow(
                      cells: <DataCell>[
                        DataCell(Text('O-')),
                        DataCell(Text('A+, A-, B+, B-, AB+, AB-, O-')),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: CompatibilityPage(),
  ));
}
