import 'package:soul_saver/core/app_export.dart';
import 'package:soul_saver/presentation/compatibility_chart_bottomsheet/models/compatibility_chart_model.dart';

class CompatibilityChartController extends GetxController {
  Rx<CompatibilityChartModel> compatibilityChartModelObj =
      CompatibilityChartModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
