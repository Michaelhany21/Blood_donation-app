import 'package:soul_saver/core/app_export.dart';
import 'package:soul_saver/presentation/welcome_screen/models/welcome_model.dart';

class WelcomeController extends GetxController {
  Rx<WelcomeModel> welcomeModelObj = WelcomeModel().obs;

  @override
  void onReady() {
    super.onReady();
    Future.delayed(const Duration(milliseconds: 3000), () {
      Get.toNamed(AppRoutes.logInScreen);
    });
  }

  @override
  void onClose() {
    super.onClose();
  }
}
