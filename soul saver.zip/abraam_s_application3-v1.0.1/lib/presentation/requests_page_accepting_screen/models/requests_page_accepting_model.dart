class RequestsPageAcceptingModel {}
