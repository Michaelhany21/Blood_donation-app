// ignore_for_file: unused_import

import 'controller/requests_page_accepting_controller.dart';
import 'package:soul_saver/core/app_export.dart';
import 'package:soul_saver/presentation/notifications_page/notifications_page.dart';
import 'package:soul_saver/presentation/request_donation_sent_page/request_donation_sent_page.dart';
import 'package:soul_saver/widgets/custom_bottom_bar.dart';
import 'package:soul_saver/widgets/custom_button.dart';
import 'package:flutter/material.dart';

class RequestsPageAcceptingScreen
    extends GetWidget<RequestsPageAcceptingController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: Container(
                height: size.height,
                width: double.maxFinite,
                decoration: AppDecoration.fillWhiteA700,
                child: Stack(alignment: Alignment.bottomCenter, children: [
                  Align(
                      alignment: Alignment.center,
                      child: Container(
                          width: double.maxFinite,
                          margin: getMargin(bottom: 1),
                          padding: getPadding(
                              left: 34, top: 37, right: 34, bottom: 37),
                          decoration: AppDecoration.fillRed800,
                          child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                CustomImageView(
                                    svgPath:
                                        ImageConstant.imgArrowleftWhiteA700,
                                    height: getVerticalSize(15),
                                    width: getHorizontalSize(9),
                                    margin: getMargin(top: 4, bottom: 716),
                                    onTap: () {
                                      onTapImgArrowleft();
                                    }),
                                Padding(
                                    padding: getPadding(left: 20, bottom: 711),
                                    child: Text("lbl_requests".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style: AppStyle
                                            .txtMontserratBold20WhiteA700))
                              ]))),
                  Align(
                      alignment: Alignment.bottomCenter,
                      child: Container(
                          margin: getMargin(top: 85),
                          padding: getPadding(
                              left: 29, top: 18, right: 29, bottom: 18),
                          decoration: AppDecoration.fillWhiteA700.copyWith(
                              borderRadius: BorderRadiusStyle.customBorderTL30),
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Padding(
                                    padding: getPadding(left: 3),
                                    child: Row(children: [
                                      Padding(
                                          padding:
                                              getPadding(top: 7, bottom: 1),
                                          child: Text("lbl_name".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratRegular9)),
                                      Padding(
                                          padding: getPadding(left: 15),
                                          child: Text("lbl_dr_will_tunde".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratMedium16))
                                    ])),
                                Padding(
                                    padding: getPadding(left: 3, top: 13),
                                    child: Row(children: [
                                      Padding(
                                          padding:
                                              getPadding(top: 1, bottom: 2),
                                          child: Text("lbl_location".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratRegular9)),
                                      Padding(
                                          padding: getPadding(left: 4),
                                          child: Text("msg_general_hospital".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratRegular12Gray800))
                                    ])),
                                Padding(
                                    padding: getPadding(left: 3, top: 12),
                                    child: Row(children: [
                                      Padding(
                                          padding:
                                              getPadding(top: 1, bottom: 2),
                                          child: Text("lbl_address".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratRegular9)),
                                      Padding(
                                          padding: getPadding(left: 7),
                                          child: Text(
                                              "msg_1_abiola_way_akure".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratRegular12Gray800))
                                    ])),
                                Padding(
                                    padding: getPadding(left: 3, top: 10),
                                    child: Row(children: [
                                      Padding(
                                          padding:
                                              getPadding(top: 2, bottom: 1),
                                          child: Text("lbl_date2".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratRegular9)),
                                      Padding(
                                          padding: getPadding(left: 22),
                                          child: Text("lbl_3_3_21".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratRegular12Gray800))
                                    ])),
                                Padding(
                                    padding: getPadding(left: 3, top: 15),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Expanded(
                                              child: CustomButton(
                                                  height: getVerticalSize(38),
                                                  text: "lbl_accept".tr,
                                                  margin:
                                                      getMargin(right: 19))),
                                          Expanded(
                                              child: CustomButton(
                                                  height: getVerticalSize(38),
                                                  text: "lbl_reject".tr,
                                                  margin: getMargin(left: 19),
                                                  variant: ButtonVariant
                                                      .OutlineRed800,
                                                  fontStyle: ButtonFontStyle
                                                      .MontserratSemiBold12Gray800))
                                        ])),
                                Spacer(),
                                Padding(
                                    padding: getPadding(left: 3),
                                    child: Row(children: [
                                      Padding(
                                          padding:
                                              getPadding(top: 7, bottom: 1),
                                          child: Text("lbl_name".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratRegular9)),
                                      Padding(
                                          padding: getPadding(left: 15),
                                          child: Text("lbl_dr_will_tunde".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratMedium16))
                                    ])),
                                Padding(
                                    padding: getPadding(left: 3, top: 13),
                                    child: Row(children: [
                                      Padding(
                                          padding:
                                              getPadding(top: 1, bottom: 2),
                                          child: Text("lbl_location".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratRegular9)),
                                      Padding(
                                          padding: getPadding(left: 4),
                                          child: Text("msg_general_hospital".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratRegular12Gray800))
                                    ])),
                                Padding(
                                    padding: getPadding(left: 3, top: 12),
                                    child: Row(children: [
                                      Padding(
                                          padding:
                                              getPadding(top: 1, bottom: 2),
                                          child: Text("lbl_address".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratRegular9)),
                                      Padding(
                                          padding: getPadding(left: 7),
                                          child: Text(
                                              "msg_1_abiola_way_akure".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratRegular12Gray800))
                                    ])),
                                Padding(
                                    padding: getPadding(left: 3, top: 10),
                                    child: Row(children: [
                                      Padding(
                                          padding:
                                              getPadding(top: 2, bottom: 1),
                                          child: Text("lbl_date2".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratRegular9)),
                                      Padding(
                                          padding: getPadding(left: 22),
                                          child: Text("lbl_3_3_21".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratRegular12Gray800))
                                    ])),
                                Padding(
                                    padding: getPadding(
                                        left: 3, top: 15, bottom: 179),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Expanded(
                                              child: CustomButton(
                                                  height: getVerticalSize(38),
                                                  text: "lbl_accept".tr,
                                                  margin:
                                                      getMargin(right: 19))),
                                          Expanded(
                                              child: CustomButton(
                                                  height: getVerticalSize(38),
                                                  text: "lbl_reject".tr,
                                                  margin: getMargin(left: 19),
                                                  variant: ButtonVariant
                                                      .OutlineRed800,
                                                  fontStyle: ButtonFontStyle
                                                      .MontserratSemiBold12Gray800))
                                        ]))
                              ]))),
                  Align(
                      alignment: Alignment.bottomCenter,
                      child: Container(
                          padding: getPadding(
                              left: 29, top: 15, right: 29, bottom: 15),
                          decoration: AppDecoration.outlineGray400,
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Padding(
                                    padding: getPadding(left: 3),
                                    child: Row(children: [
                                      Padding(
                                          padding:
                                              getPadding(top: 7, bottom: 1),
                                          child: Text("lbl_name".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratRegular9)),
                                      Padding(
                                          padding: getPadding(left: 15),
                                          child: Text("lbl_dr_will_tunde".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratMedium16))
                                    ])),
                                Padding(
                                    padding: getPadding(left: 3, top: 13),
                                    child: Row(children: [
                                      Padding(
                                          padding:
                                              getPadding(top: 1, bottom: 2),
                                          child: Text("lbl_location".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratRegular9)),
                                      Padding(
                                          padding: getPadding(left: 4),
                                          child: Text("msg_general_hospital".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratRegular12Gray800))
                                    ])),
                                Padding(
                                    padding: getPadding(left: 3, top: 12),
                                    child: Row(children: [
                                      Padding(
                                          padding:
                                              getPadding(top: 1, bottom: 2),
                                          child: Text("lbl_address".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratRegular9)),
                                      Padding(
                                          padding: getPadding(left: 7),
                                          child: Text(
                                              "msg_1_abiola_way_akure".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratRegular12Gray800))
                                    ])),
                                Padding(
                                    padding: getPadding(left: 3, top: 10),
                                    child: Row(children: [
                                      Padding(
                                          padding:
                                              getPadding(top: 2, bottom: 1),
                                          child: Text("lbl_date2".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratRegular9)),
                                      Padding(
                                          padding: getPadding(left: 22),
                                          child: Text("lbl_3_3_21".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratRegular12Gray800))
                                    ])),
                                Padding(
                                    padding:
                                        getPadding(left: 3, top: 15, bottom: 9),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Expanded(
                                              child: Container(
                                                  margin: getMargin(right: 19),
                                                  padding: getPadding(
                                                      left: 42,
                                                      top: 4,
                                                      right: 42,
                                                      bottom: 4),
                                                  decoration:
                                                      AppDecoration.fillGray400,
                                                  child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Padding(
                                                            padding: getPadding(
                                                                top: 1),
                                                            child: Text(
                                                                "lbl_accept".tr,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .left,
                                                                style: AppStyle
                                                                    .txtMontserratSemiBold12Gray800))
                                                      ]))),
                                          Expanded(
                                              child: Container(
                                                  margin: getMargin(left: 19),
                                                  padding: getPadding(
                                                      left: 49,
                                                      top: 4,
                                                      right: 49,
                                                      bottom: 4),
                                                  decoration: AppDecoration
                                                      .outlineGray4001,
                                                  child: Column(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Padding(
                                                            padding: getPadding(
                                                                top: 1),
                                                            child: Text(
                                                                "lbl_reject".tr,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .left,
                                                                style: AppStyle
                                                                    .txtMontserratSemiBold12Gray800))
                                                      ])))
                                        ]))
                              ]))),
                  Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                          margin: getMargin(top: 277),
                          padding: getPadding(
                              left: 29, top: 13, right: 29, bottom: 13),
                          decoration: AppDecoration.outlineGray400,
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Padding(
                                    padding: getPadding(left: 3, top: 2),
                                    child: Row(children: [
                                      Padding(
                                          padding:
                                              getPadding(top: 7, bottom: 1),
                                          child: Text("lbl_name".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratRegular9)),
                                      Padding(
                                          padding: getPadding(left: 15),
                                          child: Text("lbl_dr_will_tunde".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratMedium16))
                                    ])),
                                Padding(
                                    padding: getPadding(left: 3, top: 13),
                                    child: Row(children: [
                                      Padding(
                                          padding:
                                              getPadding(top: 1, bottom: 2),
                                          child: Text("lbl_location".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratRegular9)),
                                      Padding(
                                          padding: getPadding(left: 4),
                                          child: Text("msg_general_hospital".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratRegular12Gray800))
                                    ])),
                                Padding(
                                    padding: getPadding(left: 3, top: 12),
                                    child: Row(children: [
                                      Padding(
                                          padding:
                                              getPadding(top: 1, bottom: 2),
                                          child: Text("lbl_address".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratRegular9)),
                                      Padding(
                                          padding: getPadding(left: 7),
                                          child: Text(
                                              "msg_1_abiola_way_akure".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratRegular12Gray800))
                                    ])),
                                Padding(
                                    padding: getPadding(left: 3, top: 10),
                                    child: Row(children: [
                                      Padding(
                                          padding:
                                              getPadding(top: 2, bottom: 1),
                                          child: Text("lbl_date2".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratRegular9)),
                                      Padding(
                                          padding: getPadding(left: 22),
                                          child: Text("lbl_3_3_21".tr,
                                              overflow: TextOverflow.ellipsis,
                                              textAlign: TextAlign.left,
                                              style: AppStyle
                                                  .txtMontserratRegular12Gray800))
                                    ])),
                                Padding(
                                    padding: getPadding(left: 3, top: 15),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Expanded(
                                              child: Container(
                                                  margin: getMargin(right: 19),
                                                  padding: getPadding(
                                                      left: 46,
                                                      top: 10,
                                                      right: 46,
                                                      bottom: 10),
                                                  decoration: AppDecoration
                                                      .fillRed800
                                                      .copyWith(
                                                          borderRadius:
                                                              BorderRadiusStyle
                                                                  .roundedBorder6),
                                                  child: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Padding(
                                                            padding: getPadding(
                                                                top: 1),
                                                            child: Text(
                                                                "lbl_accept".tr,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .left,
                                                                style: AppStyle
                                                                    .txtMontserratSemiBold12))
                                                      ]))),
                                          Expanded(
                                              child: Container(
                                                  margin: getMargin(left: 19),
                                                  padding: getPadding(
                                                      left: 49,
                                                      top: 10,
                                                      right: 49,
                                                      bottom: 10),
                                                  decoration: AppDecoration
                                                      .outlineRed800
                                                      .copyWith(
                                                          borderRadius:
                                                              BorderRadiusStyle
                                                                  .roundedBorder6),
                                                  child: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Padding(
                                                            padding: getPadding(
                                                                top: 1),
                                                            child: Text(
                                                                "lbl_reject".tr,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                textAlign:
                                                                    TextAlign
                                                                        .left,
                                                                style: AppStyle
                                                                    .txtMontserratSemiBold12Gray800))
                                                      ])))
                                        ]))
                              ]))),
                  Align(
                      alignment: Alignment.center,
                      child: Container(
                          padding: getPadding(
                              left: 42, top: 251, right: 42, bottom: 251),
                          decoration: AppDecoration.fillGray40047,
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                    margin: getMargin(right: 9, bottom: 72),
                                    padding: getPadding(
                                        left: 38,
                                        top: 32,
                                        right: 38,
                                        bottom: 32),
                                    decoration: AppDecoration.fillWhiteA700,
                                    child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Container(
                                              height: getVerticalSize(115),
                                              width: getHorizontalSize(119),
                                              child: Stack(
                                                  alignment: Alignment.center,
                                                  children: [
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgCheckmark,
                                                        height:
                                                            getVerticalSize(35),
                                                        width:
                                                            getHorizontalSize(
                                                                56),
                                                        alignment:
                                                            Alignment.center),
                                                    Align(
                                                        alignment:
                                                            Alignment.center,
                                                        child: Container(
                                                            height:
                                                                getVerticalSize(
                                                                    115),
                                                            width:
                                                                getHorizontalSize(
                                                                    119),
                                                            decoration: BoxDecoration(
                                                                borderRadius:
                                                                    BorderRadius.circular(
                                                                        getHorizontalSize(
                                                                            59)),
                                                                border: Border.all(
                                                                    color: ColorConstant
                                                                        .red800,
                                                                    width: getHorizontalSize(
                                                                        10)))))
                                                  ])),
                                          Padding(
                                              padding: getPadding(
                                                  top: 22, bottom: 0),
                                              child: Text(
                                                  "msg_thanks_for_accepting".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtMontserratBold18))
                                        ]))
                              ])))
                ])),
            ));
  }



  onTapImgArrowleft() {
    Get.back();
  }
}
