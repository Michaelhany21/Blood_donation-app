// ignore_for_file: unused_import

import 'package:soul_saver/core/app_export.dart';
import 'package:soul_saver/presentation/requests_page_accepting_screen/models/requests_page_accepting_model.dart';
import 'package:soul_saver/widgets/custom_bottom_bar.dart';

class RequestsPageAcceptingController extends GetxController {
  Rx<RequestsPageAcceptingModel> requestsPageAcceptingModelObj =
      RequestsPageAcceptingModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
