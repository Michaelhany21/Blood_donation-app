import '../controller/requests_page_accepting_controller.dart';
import 'package:get/get.dart';

class RequestsPageAcceptingBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => RequestsPageAcceptingController());
  }
}
