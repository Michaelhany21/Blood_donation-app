import 'package:soul_saver/core/app_export.dart';
import 'package:soul_saver/presentation/donate_page_bottomsheet/models/donate_page_model.dart';
import 'package:flutter/material.dart';

class DonatePageController extends GetxController {
  TextEditingController dateController = TextEditingController();

  TextEditingController locationController = TextEditingController();

  Rx<DonatePageModel> donatePageModelObj = DonatePageModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
    dateController.dispose();
    locationController.dispose();
  }
}
