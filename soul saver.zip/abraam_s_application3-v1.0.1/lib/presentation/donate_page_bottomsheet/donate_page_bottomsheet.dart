import 'controller/donate_page_controller.dart';
import 'package:soul_saver/core/app_export.dart';
import 'package:soul_saver/widgets/custom_button.dart';
import 'package:soul_saver/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class DonatePageBottomsheet extends StatelessWidget {
  DonatePageBottomsheet(this.controller);

  DonatePageController controller;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        width: double.maxFinite,
        child: Container(
          width: double.maxFinite,
          padding: getPadding(
            left: 22,
            top: 54,
            right: 22,
            bottom: 54,
          ),
          decoration: AppDecoration.fillWhiteA700.copyWith(
            borderRadius: BorderRadiusStyle.customBorderTL30,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              CustomTextFormField(
                focusNode: FocusNode(),
                controller: controller.dateController,
                hintText: "lbl_date".tr,
                padding: TextFormFieldPadding.PaddingT22,
              ),
              Container(
                height: getVerticalSize(
                  61,
                ),
                width: getHorizontalSize(
                  331,
                ),
                margin: getMargin(
                  top: 36,
                ),
                child: Stack(
                  alignment: Alignment.centerRight,
                  children: [
                    Align(
                      alignment: Alignment.center,
                      child: Container(
                        margin: getMargin(
                          top: 1,
                        ),
                        padding: getPadding(
                          left: 11,
                          right: 11,
                        ),
                        decoration: AppDecoration.outlineBlack900,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Padding(
                              padding: getPadding(
                                top: 25,
                                bottom: 19,
                              ),
                              child: Text(
                                "lbl_time".tr,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.left,
                                style: AppStyle.txtMontserratRegular12,
                              ),
                            ),
                            CustomButton(
                              height: getVerticalSize(
                                60,
                              ),
                              width: getHorizontalSize(
                                68,
                              ),
                              text: "lbl_am".tr,
                              margin: getMargin(
                                right: 57,
                              ),
                              shape: ButtonShape.Square,
                              padding: ButtonPadding.PaddingT17,
                              fontStyle: ButtonFontStyle.MontserratMedium21,
                            ),
                          ],
                        ),
                      ),
                    ),
                    CustomButton(
                      height: getVerticalSize(
                        60,
                      ),
                      width: getHorizontalSize(
                        68,
                      ),
                      text: "lbl_pm".tr,
                      variant: ButtonVariant.FillGray200a0,
                      shape: ButtonShape.Square,
                      padding: ButtonPadding.PaddingT17,
                      fontStyle: ButtonFontStyle.MontserratMedium21Gray900,
                      alignment: Alignment.centerRight,
                    ),
                  ],
                ),
              ),
              Container(
                height: getVerticalSize(
                  60,
                ),
                width: getHorizontalSize(
                  331,
                ),
                margin: getMargin(
                  top: 34,
                ),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Align(
                      alignment: Alignment.bottomLeft,
                      child: Padding(
                        padding: getPadding(
                          left: 11,
                          bottom: 20,
                        ),
                        child: Text(
                          "lbl_time_needed".tr,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: AppStyle.txtMontserratRegular12,
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.center,
                      child: Container(
                        height: getVerticalSize(
                          60,
                        ),
                        width: getHorizontalSize(
                          331,
                        ),
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: ColorConstant.black900,
                            width: getHorizontalSize(
                              1,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              CustomTextFormField(
                focusNode: FocusNode(),
                controller: controller.locationController,
                hintText: "lbl_location".tr,
                margin: getMargin(
                  top: 37,
                ),
                padding: TextFormFieldPadding.PaddingT22,
                textInputAction: TextInputAction.done,
              ),
              CustomButton(
                height: getVerticalSize(
                  57,
                ),
                text: "lbl_donate".tr,
                margin: getMargin(
                  top: 72,
                  bottom: 142,
                ),
                shape: ButtonShape.RoundedBorder10,
                padding: ButtonPadding.PaddingAll19,
                fontStyle: ButtonFontStyle.MontserratSemiBold14,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
