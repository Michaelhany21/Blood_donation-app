import 'controller/request_donation_sent_controller.dart';
import 'models/request_donation_sent_model.dart';
import 'package:soul_saver/core/app_export.dart';
import 'package:soul_saver/widgets/custom_button.dart';
import 'package:soul_saver/widgets/custom_drop_down.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class RequestDonationSentPage extends StatelessWidget {
  RequestDonationSentController controller =
      Get.put(RequestDonationSentController(RequestDonationSentModel().obs));

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: Colors.transparent,
            body:SingleChildScrollView(
            child: Container(
                height: getVerticalSize(767),
                width: double.maxFinite,
                child: Stack(children: [
                  Align(
                      alignment: Alignment.center,
                      child: Container(
                          height: getVerticalSize(767),
                          width: double.maxFinite,
                          decoration: AppDecoration.fillWhiteA700,
                          child: Stack(
                              alignment: Alignment.bottomCenter,
                              children: [
                                Align(
                                    alignment: Alignment.center,
                                    child: Container(
                                        width: double.maxFinite,
                                        padding: getPadding(
                                            left: 26,
                                            top: 37,
                                            right: 26,
                                            bottom: 37),
                                        decoration: AppDecoration.fillRed800,
                                        child: Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              CustomImageView(
                                                  svgPath: ImageConstant
                                                      .imgArrowleftWhiteA700,
                                                  height: getVerticalSize(11),
                                                  width: getHorizontalSize(7),
                                                  margin: getMargin(
                                                      top: 6, bottom: 719),
                                                  onTap: () {
                                                    onTapImgArrowleft();
                                                  }),
                                              Padding(
                                                  padding: getPadding(
                                                      left: 5, bottom: 711),
                                                  child: Text(
                                                      "msg_request_for_blood"
                                                          .tr,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtMontserratBold20WhiteA700))
                                            ]))),
                                Align(
                                    alignment: Alignment.bottomCenter,
                                    child: Container(
                                        padding: getPadding(
                                            left: 22,
                                            top: 61,
                                            right: 22,
                                            bottom: 61),
                                        decoration: AppDecoration.fillWhiteA700
                                            .copyWith(
                                                borderRadius: BorderRadiusStyle
                                                    .customBorderTL30),
                                        child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              CustomDropDown(
                                                  focusNode: FocusNode(),
                                                  icon: Container(
                                                      margin: getMargin(
                                                          left: 30, right: 48),
                                                      decoration: BoxDecoration(
                                                          border: Border.all(
                                                              color:
                                                                  ColorConstant
                                                                      .gray900,
                                                              width:
                                                                  getHorizontalSize(
                                                                      2),
                                                              strokeAlign:
                                                                  BorderSide.strokeAlignCenter)),
                                                      child: CustomImageView(
                                                          svgPath: ImageConstant
                                                              .imgArrowdown)),
                                                  hintText: "lbl_genotype".tr,
                                                  items: controller
                                                      .requestDonationSentModelObj
                                                      .value
                                                      .dropdownItemList,
                                                  onChanged: (value) {
                                                    controller
                                                        .onSelected(value);
                                                  }),
                                              Container(
                                                  height: getVerticalSize(251),
                                                  width: getHorizontalSize(331),
                                                  margin: getMargin(top: 37),
                                                  child: Stack(
                                                      alignment:
                                                          Alignment.topCenter,
                                                      children: [
                                                        Align(
                                                            alignment: Alignment
                                                                .bottomCenter,
                                                            child: Container(
                                                                padding:
                                                                    getPadding(
                                                                        left:
                                                                            11,
                                                                        top: 20,
                                                                        right:
                                                                            11,
                                                                        bottom:
                                                                            20),
                                                                decoration:
                                                                    AppDecoration
                                                                        .outlineBlack900,
                                                                child: Column(
                                                                    mainAxisSize:
                                                                        MainAxisSize
                                                                            .min,
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .start,
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .center,
                                                                    children: [
                                                                      Padding(
                                                                          padding: getPadding(
                                                                              top:
                                                                                  1),
                                                                          child: Text(
                                                                              "msg_institution_name".tr,
                                                                              overflow: TextOverflow.ellipsis,
                                                                              textAlign: TextAlign.left,
                                                                              style: AppStyle.txtMontserratRegular14Gray500))
                                                                    ]))),
                                                        CustomDropDown(
                                                            width:
                                                                getHorizontalSize(
                                                                    331),
                                                            focusNode:
                                                                FocusNode(),
                                                            icon: Container(
                                                                margin: getMargin(
                                                                    left: 30,
                                                                    right: 48),
                                                                decoration: BoxDecoration(
                                                                    border: Border.all(
                                                                        color: ColorConstant
                                                                            .gray900,
                                                                        width: getHorizontalSize(
                                                                            2),
                                                                        strokeAlign: BorderSide.strokeAlignCenter)),
                                                                child: CustomImageView(
                                                                    svgPath:
                                                                        ImageConstant
                                                                            .imgArrowdown)),
                                                            hintText:
                                                                "lbl_blood_group"
                                                                    .tr,
                                                            alignment: Alignment
                                                                .topCenter,
                                                            items: controller
                                                                .requestDonationSentModelObj
                                                                .value
                                                                .dropdownItemList1,
                                                            onChanged: (value) {
                                                              controller
                                                                  .onSelected1(
                                                                      value);
                                                            }),
                                                        Align(
                                                            alignment: Alignment
                                                                .centerLeft,
                                                            child: Padding(
                                                                padding:
                                                                    getPadding(
                                                                        left:
                                                                            11),
                                                                child: Text(
                                                                    "lbl_time_needed"
                                                                        .tr,
                                                                    overflow:
                                                                        TextOverflow
                                                                            .ellipsis,
                                                                    textAlign:
                                                                        TextAlign
                                                                            .left,
                                                                    style: AppStyle
                                                                        .txtMontserratRegular14Gray500))),
                                                        Align(
                                                            alignment: Alignment
                                                                .center,
                                                            child: Container(
                                                                height: getVerticalSize(
                                                                    60),
                                                                width:
                                                                    getHorizontalSize(
                                                                        331),
                                                                decoration: BoxDecoration(
                                                                    border: Border.all(
                                                                        color: ColorConstant
                                                                            .black900,
                                                                        width: getHorizontalSize(
                                                                            1))))),
                                                        Align(
                                                            alignment: Alignment
                                                                .center,
                                                            child: Container(
                                                                margin:
                                                                    getMargin(
                                                                        left:
                                                                            25,
                                                                        right:
                                                                            24),
                                                                padding:
                                                                    getPadding(
                                                                        left:
                                                                            70,
                                                                        top: 39,
                                                                        right:
                                                                            70,
                                                                        bottom:
                                                                            39),
                                                                decoration:
                                                                    AppDecoration
                                                                        .fillWhiteA700,
                                                                child: Column(
                                                                    mainAxisSize:
                                                                        MainAxisSize
                                                                            .min,
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .start,
                                                                    children: [
                                                                      Container(
                                                                          height: getVerticalSize(
                                                                              115),
                                                                          width: getHorizontalSize(
                                                                              119),
                                                                          child: Stack(
                                                                              alignment: Alignment.center,
                                                                              children: [
                                                                                CustomImageView(svgPath: ImageConstant.imgCheckmark, height: getVerticalSize(35), width: getHorizontalSize(56), alignment: Alignment.center),
                                                                                Align(alignment: Alignment.center, child: Container(height: getVerticalSize(115), width: getHorizontalSize(119), decoration: BoxDecoration(borderRadius: BorderRadius.circular(getHorizontalSize(59)), border: Border.all(color: ColorConstant.red800, width: getHorizontalSize(5)))))
                                                                              ])),
                                                                      Padding(
                                                                          padding: getPadding(
                                                                              top:
                                                                                  18,
                                                                              bottom:
                                                                                  5),
                                                                          child: Text(
                                                                              "lbl_request_sent".tr,
                                                                              overflow: TextOverflow.ellipsis,
                                                                              textAlign: TextAlign.left,
                                                                              style: AppStyle.txtMontserratBold20Bluegray900))
                                                                    ])))
                                                      ])),
                                              CustomButton(
                                                  height: getVerticalSize(57),
                                                  text: "lbl_request".tr,
                                                  margin: getMargin(
                                                      top: 65, bottom: 135),
                                                  shape: ButtonShape
                                                      .RoundedBorder10,
                                                  padding: ButtonPadding
                                                      .PaddingAll19,
                                                  fontStyle: ButtonFontStyle
                                                      .MontserratSemiBold14)
                                            ]))),
                                Align(
                                    alignment: Alignment.center,
                                    child: Container(
                                        height: size.height,
                                        width: double.maxFinite,
                                        decoration: BoxDecoration(
                                            color: ColorConstant.gray40047)))
                              ])))
                ])))));
  }

  onTapImgArrowleft() {
    Get.back();
  }
}
