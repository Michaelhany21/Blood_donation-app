import 'package:get/get.dart';
import 'package:soul_saver/data/models/selectionPopupModel/selection_popup_model.dart';

class RequestDonationSentModel {
  RxList<SelectionPopupModel> dropdownItemList = [
    SelectionPopupModel(
      id: 1,
      title: "Item One",
      isSelected: true, text: '',
    ),
    SelectionPopupModel(
      id: 2,
      title: "Item Two", text: '',
    ),
    SelectionPopupModel(
      id: 3,
      title: "Item Three", text: '',
    )
  ].obs;

  RxList<SelectionPopupModel> dropdownItemList1 = [
    SelectionPopupModel(
      id: 1,
      title: "Item One",
      isSelected: true, text: '',
    ),
    SelectionPopupModel(
      id: 2,
      title: "Item Two", text: '',
    ),
    SelectionPopupModel(
      id: 3,
      title: "Item Three", text: '',
    )
  ].obs;
}
