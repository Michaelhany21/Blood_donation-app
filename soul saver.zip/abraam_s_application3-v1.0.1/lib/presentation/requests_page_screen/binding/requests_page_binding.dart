import '../controller/requests_page_controller.dart';
import 'package:get/get.dart';

class RequestsPageBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => RequestsPageController());
  }
}
