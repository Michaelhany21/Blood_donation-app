// ignore_for_file: unused_import

import 'package:soul_saver/core/app_export.dart';
import 'package:soul_saver/presentation/requests_page_screen/models/requests_page_model.dart';
import 'package:soul_saver/widgets/custom_bottom_bar.dart';

class RequestsPageController extends GetxController {
  Rx<RequestsPageModel> requestsPageModelObj = RequestsPageModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
