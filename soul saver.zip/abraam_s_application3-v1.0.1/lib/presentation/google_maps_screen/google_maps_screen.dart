import 'controller/google_maps_controller.dart';
import 'package:soul_saver/core/app_export.dart';
import 'package:soul_saver/widgets/app_bar/appbar_image.dart';
import 'package:soul_saver/widgets/app_bar/custom_app_bar.dart';
import 'package:soul_saver/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

class GoogleMapsScreen extends GetWidget<GoogleMapsController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            extendBody: true,
            extendBodyBehindAppBar: true,
            resizeToAvoidBottomInset: false,
            backgroundColor: ColorConstant.whiteA700,
            body: Container(
                width: size.width,
                height: size.height,
                decoration: BoxDecoration(
                    color: ColorConstant.whiteA700,
                    image: DecorationImage(
                        image: AssetImage(ImageConstant.imgGooglemaps),
                        fit: BoxFit.cover)),
                child: Container(
                    width: double.maxFinite,
                    padding: getPadding(top: 26, bottom: 26),
                    child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          CustomAppBar(
                              height: getVerticalSize(65),
                              leadingWidth: 24,
                              leading: AppbarImage(
                                  height: getVerticalSize(15),
                                  width: getHorizontalSize(9),
                                  svgPath:
                                      ImageConstant.imgArrowleftWhiteA70015x9,
                                  margin:
                                      getMargin(left: 15, top: 19, bottom: 26),
                                  onTap: onTapArrowleft2),
                              title: CustomTextFormField(
                                  width: getHorizontalSize(331),
                                  focusNode: FocusNode(),
                                  controller: controller.languageController,
                                  hintText: "lbl_search_here".tr,
                                  margin: getMargin(left: 10),
                                  variant:
                                      TextFormFieldVariant.OutlineBlack900_1,
                                  fontStyle: TextFormFieldFontStyle
                                      .MontserratRegular20,
                                  textInputAction: TextInputAction.done))
                        ])))));
  }

  onTapArrowleft2() {
    Get.back();
  }
}
