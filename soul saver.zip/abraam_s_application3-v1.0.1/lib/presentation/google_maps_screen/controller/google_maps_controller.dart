import 'package:soul_saver/core/app_export.dart';
import 'package:soul_saver/presentation/google_maps_screen/models/google_maps_model.dart';
import 'package:flutter/material.dart';

class GoogleMapsController extends GetxController {
  TextEditingController languageController = TextEditingController();

  Rx<GoogleMapsModel> googleMapsModelObj = GoogleMapsModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
    languageController.dispose();
  }
}
