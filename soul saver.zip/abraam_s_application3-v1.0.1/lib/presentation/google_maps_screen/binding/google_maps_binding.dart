import '../controller/google_maps_controller.dart';
import 'package:get/get.dart';

class GoogleMapsBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => GoogleMapsController());
  }
}
