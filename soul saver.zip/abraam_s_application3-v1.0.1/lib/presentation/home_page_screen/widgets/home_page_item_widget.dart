import '../controller/home_page_controller.dart';
import '../models/home_page_item_model.dart';
import 'package:soul_saver/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class HomePageItemWidget extends StatelessWidget {
  HomePageItemWidget(this.homePageItemModelObj);

  HomePageItemModel homePageItemModelObj;

  var controller = Get.find<HomePageController>();

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Container(
          padding: getPadding(
            left: 32,
            top: 30,
            right: 32,
            bottom: 30,
          ),
          decoration: AppDecoration.outlineBlack9003f.copyWith(
            borderRadius: BorderRadiusStyle.roundedBorder6,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              CustomImageView(
                svgPath: ImageConstant.imgLocation,
                height: getVerticalSize(
                  44,
                ),
                width: getHorizontalSize(
                  28,
                ),
                margin: getMargin(
                  top: 7,
                  right: 14,
                ),
              ),
              Container(
                width: getHorizontalSize(
                  60,
                ),
                child: Obx(
                  () => Text(
                    homePageItemModelObj.donationcentresOneTxt.value,
                    maxLines: null,
                    textAlign: TextAlign.center,
                    style: AppStyle.txtMontserratRegular13Black9001,
                  ),
                ),
              ),
            ],
          ),
        ),
        Container(
          padding: getPadding(
            left: 34,
            top: 35,
            right: 34,
            bottom: 35,
          ),
          decoration: AppDecoration.outlineBlack9003f.copyWith(
            borderRadius: BorderRadiusStyle.roundedBorder6,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CustomImageView(
                svgPath: ImageConstant.imgLocationRed800,
                height: getVerticalSize(
                  47,
                ),
                width: getHorizontalSize(
                  46,
                ),
              ),
              Padding(
                padding: getPadding(
                  top: 7,
                  bottom: 3,
                ),
                child: Obx(
                  () => Text(
                    homePageItemModelObj.requestTxt.value,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.left,
                    style: AppStyle.txtMontserratRegular13Black900,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
