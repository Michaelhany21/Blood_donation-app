
// ignore_for_file: unused_import

import 'package:soul_saver/presentation/app_navigation_screen/app_navigation_screen.dart';
import 'package:soul_saver/presentation/compatibility_chart_bottomsheet/compatibility_chart_bottomsheet.dart';
import 'package:soul_saver/presentation/donate_page_bottomsheet/models/donate_page_model.dart';
import 'package:soul_saver/presentation/donation_centers_screen/donation_centers_screen.dart';
import 'package:soul_saver/presentation/donor_detail_screen/donor_detail_screen.dart';
import 'package:soul_saver/presentation/donor_list_screen/donor_list_screen.dart';
import 'package:soul_saver/presentation/profile_screen/profile_screen.dart';
import 'package:soul_saver/presentation/requests_page_screen/requests_page_screen.dart';

import '../contact_donor_screen/contact_donor_screen.dart';
import '../notifications_page/notifications_page.dart';

import '../request_donation_pageone_bottomsheet/request_screen.dart';
import 'controller/home_page_controller.dart';
import 'package:soul_saver/core/app_export.dart';
import 'package:flutter/material.dart';

class HomePageScreen extends GetWidget<HomePageController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: Container(
                width: double.maxFinite,
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Expanded(
                          child: SingleChildScrollView(
                              child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Container(
                                        height: getVerticalSize(604),
                                        width: double.maxFinite,
                                        child: Stack(
                                            alignment: Alignment.topCenter,
                                            children: [
                                              Align(
                                                  alignment: Alignment.bottomLeft,
                                                  child:
                                                  Padding(
                                                      padding:
                                                      getPadding(left: 130, top: 39, right: 17),
                                                      child: Row(
                                                          mainAxisAlignment:
                                                          MainAxisAlignment.spaceBetween,
                                                          children: [
                                                            Container(
                                                                padding: getPadding(
                                                                    left: 29,
                                                                    top: 27,
                                                                    right: 29,
                                                                    bottom: 27),
                                                                decoration: AppDecoration
                                                                    .outlineBlack9003f
                                                                    .copyWith(
                                                                    borderRadius:
                                                                    BorderRadiusStyle
                                                                        .roundedBorder6),
                                                                child: GestureDetector(
                                                                  onTap: () {
                                                                    // Navigate to the other screen
                                                                    Navigator.push(
                                                                      context,
                                                                      MaterialPageRoute(builder: (context) => DonorDetailScreen()),
                                                                    );
                                                                  },
                                                                  child: Column(
                                                                    mainAxisSize: MainAxisSize.min,
                                                                    crossAxisAlignment: CrossAxisAlignment.end,
                                                                    mainAxisAlignment: MainAxisAlignment.end,
                                                                    children: [
                                                                      CustomImageView(
                                                                        svgPath: ImageConstant.imgClock,
                                                                        height: getSize(35),
                                                                        width: getSize(35),
                                                                        margin: getMargin(top: 24, right: 20,bottom: 20),
                                                                      ),
                                                                      Container(
                                                                        width: getHorizontalSize(67),
                                                                        margin: getMargin(top: 3),
                                                                        child: Text(
                                                                          "Donate".tr,
                                                                          maxLines: null,
                                                                          textAlign: TextAlign.center,
                                                                          style: AppStyle.txtMontserratRegular13Black9001,
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                )
                                                            ),

                                                            // GestureDetector(
                                                            //   onTap: () {
                                                            //     // Navigate to the other screen
                                                            //     Navigator.push(
                                                            //       context,
                                                            //       MaterialPageRoute(builder: (context) => RequestScreen()),
                                                            //     );
                                                            //   },
                                                            //   child: Container(
                                                            //     padding: getPadding(left: 23, top: 31, right: 23, bottom: 31),
                                                            //     decoration: AppDecoration.outlineBlack9003f.copyWith(
                                                            //       borderRadius: BorderRadiusStyle.roundedBorder6,
                                                            //     ),
                                                            //     child: Column(
                                                            //       mainAxisSize: MainAxisSize.min,
                                                            //       mainAxisAlignment: MainAxisAlignment.center,
                                                            //       children: [
                                                            //         CustomImageView(
                                                            //           svgPath: ImageConstant.imgLocationRed800,
                                                            //           height: getSize(34),
                                                            //           width: getSize(34),
                                                            //         ),
                                                            //         Padding(
                                                            //           padding: getPadding(top: 28, bottom: 4),
                                                            //           child: Text(
                                                            //             "    request    ".tr,
                                                            //             overflow: TextOverflow.ellipsis,
                                                            //             textAlign: TextAlign.left,
                                                            //             style: AppStyle.txtMontserratRegular13Black900,
                                                            //           ),
                                                            //         ),
                                                            //       ],
                                                            //     ),
                                                            //   ),
                                                            // )
                                                          ])),

                                              ),
                                              Align(
                                                  alignment: Alignment.topCenter,
                                                  child: Container(
                                                      height: getVerticalSize(467),
                                                      width: double.maxFinite,
                                                      child: Stack(
                                                          alignment: Alignment.topLeft,
                                                          children: [
                                                            CustomImageView(
                                                                imagePath: ImageConstant
                                                                    .imgEllipse24,
                                                                height: getVerticalSize(
                                                                    467),
                                                                width:
                                                                getHorizontalSize(
                                                                    375),
                                                                alignment:
                                                                Alignment.center),
                                                            CustomImageView(
                                                                svgPath: ImageConstant
                                                                    .imgFreepikcharacter,
                                                                height: getVerticalSize(
                                                                    267),
                                                                width:
                                                                getHorizontalSize(
                                                                    232),
                                                                alignment:
                                                                Alignment.topLeft,
                                                                margin: getMargin(
                                                                    left: 59, top: 42))
                                                          ]))),

                                            ])),
                                    Padding(
                                        padding:
                                        getPadding(left: 14, top: 39, right: 17),
                                        child: Row(
                                            mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                            children: [
                                              Container(
                                                  padding: getPadding(
                                                      left: 29,
                                                      top: 27,
                                                      right: 29,
                                                      bottom: 27),
                                                  decoration: AppDecoration
                                                      .outlineBlack9003f
                                                      .copyWith(
                                                      borderRadius:
                                                      BorderRadiusStyle
                                                          .roundedBorder6),
                                                  child: GestureDetector(
                                                    onTap: () {
                                                      // Navigate to the other screen
                                                      Navigator.push(
                                                        context,
                                                        MaterialPageRoute(builder: (context) => DonationCentersScreen()),
                                                      );
                                                    },
                                                    child: Column(
                                                      mainAxisSize: MainAxisSize.min,
                                                      crossAxisAlignment: CrossAxisAlignment.end,
                                                      mainAxisAlignment: MainAxisAlignment.end,
                                                      children: [
                                                        CustomImageView(
                                                          svgPath: ImageConstant.imgLocation,
                                                          height: getSize(30),
                                                          width: getSize(30),
                                                          margin: getMargin(top: 24, right: 20,bottom: 20),
                                                        ),
                                                        Container(
                                                          width: getHorizontalSize(67),
                                                          margin: getMargin(top: 3),
                                                          child: Text(
                                                            "donation centers".tr,
                                                            maxLines: null,
                                                            textAlign: TextAlign.center,
                                                            style: AppStyle.txtMontserratRegular13Black9001,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  )
                                              ),

                                              GestureDetector(
                                                onTap: () {
                                                  // Navigate to the other screen
                                                  Navigator.push(
                                                    context,
                                                    MaterialPageRoute(builder: (context) => RequestScreen()),
                                                  );
                                                },
                                                child: Container(
                                                  padding: getPadding(left: 23, top: 31, right: 23, bottom: 31),
                                                  decoration: AppDecoration.outlineBlack9003f.copyWith(
                                                    borderRadius: BorderRadiusStyle.roundedBorder6,
                                                  ),
                                                  child: Column(
                                                    mainAxisSize: MainAxisSize.min,
                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                    children: [
                                                      CustomImageView(
                                                        svgPath: ImageConstant.imgLocationRed800,
                                                        height: getSize(34),
                                                        width: getSize(34),
                                                      ),
                                                      Padding(
                                                        padding: getPadding(top: 28, bottom: 4),
                                                        child: Text(
                                                          "    request    ".tr,
                                                          overflow: TextOverflow.ellipsis,
                                                          textAlign: TextAlign.left,
                                                          style: AppStyle.txtMontserratRegular13Black900,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              )
                                            ])),

                                    Padding(
                                        padding:
                                        getPadding(left: 14, top: 39, right: 17),
                                        child: Row(
                                            mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                            children: [
                                              Container(
                                                  padding: getPadding(
                                                      left: 29,
                                                      top: 27,
                                                      right: 29,
                                                      bottom: 27),
                                                  decoration: AppDecoration
                                                      .outlineBlack9003f
                                                      .copyWith(
                                                      borderRadius:
                                                      BorderRadiusStyle
                                                          .roundedBorder6),
                                                  child: GestureDetector(
                                                    onTap: () {
                                                      // Navigate to the other screen
                                                      Navigator.push(
                                                        context,
                                                        MaterialPageRoute(builder: (context) => DonorListScreen()),
                                                      );
                                                    },
                                                    child: Column(
                                                      mainAxisSize: MainAxisSize.min,
                                                      crossAxisAlignment: CrossAxisAlignment.end,
                                                      mainAxisAlignment: MainAxisAlignment.end,
                                                      children: [
                                                        CustomImageView(
                                                          svgPath: ImageConstant.imgFingerprint,
                                                          height: getSize(30),
                                                          width: getSize(30),
                                                          margin: getMargin(top: 24, right: 20,bottom: 20),
                                                        ),
                                                        Container(
                                                          width: getHorizontalSize(67),
                                                          margin: getMargin(top: 3),
                                                          child: Text(
                                                            "Call a donor".tr,
                                                            maxLines: null,
                                                            textAlign: TextAlign.center,
                                                            style: AppStyle.txtMontserratRegular13Black9001,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  )
                                              ),

                                              GestureDetector(
                                                onTap: () {
                                                  // Navigate to the other screen
                                                  Navigator.push(
                                                    context,
                                                    MaterialPageRoute(builder: (context) => NotificationsPage()),
                                                  );
                                                },
                                                child: Container(
                                                  padding: getPadding(left: 23, top: 31, right: 23, bottom: 31),
                                                  decoration: AppDecoration.outlineBlack9003f.copyWith(
                                                    borderRadius: BorderRadiusStyle.roundedBorder6,
                                                  ),
                                                  child: Column(
                                                    mainAxisSize: MainAxisSize.min,
                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                    children: [
                                                      CustomImageView(
                                                  svgPath: ImageConstant.imgFile,
                                                        height: getSize(34),
                                                        width: getSize(34),
                                                      ),
                                                      Padding(
                                                        padding: getPadding(top: 28, bottom: 4),
                                                        child: Text(
                                                          "Notifications".tr,
                                                          overflow: TextOverflow.ellipsis,
                                                          textAlign: TextAlign.left,
                                                          style: AppStyle.txtMontserratRegular13Black900,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              )
                                            ])),
                                    Padding(
                                        padding:
                                        getPadding(left: 14, top: 39, right: 17),
                                        child: Row(
                                            mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                            children: [
                                              Container(
                                                  padding: getPadding(
                                                      left: 29,
                                                      top: 27,
                                                      right: 29,
                                                      bottom: 27),
                                                  decoration: AppDecoration
                                                      .outlineBlack9003f
                                                      .copyWith(
                                                      borderRadius:
                                                      BorderRadiusStyle
                                                          .roundedBorder6),
                                                  child: GestureDetector(
                                                    onTap: () {
                                                      // Navigate to the other screen
                                                      Navigator.push(
                                                        context,
                                                        MaterialPageRoute(builder: (context) => CompatibilityPage()),
                                                      );
                                                    },
                                                    child: Column(
                                                      mainAxisSize: MainAxisSize.min,
                                                      crossAxisAlignment: CrossAxisAlignment.end,
                                                      mainAxisAlignment: MainAxisAlignment.end,
                                                      children: [
                                                        CustomImageView(
                                                        svgPath:
                                                        ImageConstant.imgMenuRed800,
                                                          height: getSize(30),
                                                          width: getSize(30),
                                                          margin: getMargin(top: 24, right: 20,bottom: 15),
                                                        ),
                                                        Container(
                                                          width: getHorizontalSize(67),
                                                          margin: getMargin(top: 3),
                                                          child: Text(
                                                            "compatibility".tr,
                                                            maxLines: null,
                                                            textAlign: TextAlign.center,
                                                            style: AppStyle.txtMontserratRegular13Black9001,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  )
                                              ),

                                              GestureDetector(
                                                onTap: () {
                                                  // Navigate to the other screen
                                                  Navigator.push(
                                                    context,
                                                    MaterialPageRoute(builder: (context) => ProfileScreen()),
                                                  );
                                                },
                                                child: Container(
                                                  padding: getPadding(left: 33, top: 31, right: 43, bottom: 31),
                                                  decoration: AppDecoration.outlineBlack9003f.copyWith(
                                                    borderRadius: BorderRadiusStyle.roundedBorder6,
                                                  ),
                                                  child: Column(
                                                    mainAxisSize: MainAxisSize.min,
                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                    children: [
                                                      CustomImageView(
                                                        svgPath: ImageConstant.imgHomeRed800,
                                                        height: getSize(34),
                                                        width: getSize(34),
                                                      ),
                                                      Padding(
                                                        padding: getPadding(top: 28, bottom: 4),
                                                        child: Text(
                                                          "profile".tr,
                                                          overflow: TextOverflow.ellipsis,
                                                          textAlign: TextAlign.left,
                                                          style: AppStyle.txtMontserratRegular13Black900,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              )
                                            ])),

                                    // Container(
                                    //     width: double.maxFinite,
                                    //     child: Container(
                                    //         margin: getMargin(top: 31),
                                    //         padding: getPadding(left: 20, right: 20),
                                    //         decoration:
                                    //         AppDecoration.outlineDeeporange100,
                                    //         child: Column(
                                    //             crossAxisAlignment:
                                    //             CrossAxisAlignment.start,
                                    //             mainAxisAlignment:
                                    //             MainAxisAlignment.start,
                                    //             children: [
                                    //               Container(
                                    //                   height: getVerticalSize(2),
                                    //                   width: getHorizontalSize(31),
                                    //                   decoration: BoxDecoration(
                                    //                       color: ColorConstant.red800)),
                                    //               Padding(
                                    //                   padding: getPadding(
                                    //                       left: 8, top: 2, right: 34),
                                    //                   child: Row(children: [
                                    //                     CustomImageView(
                                    //                         svgPath: ImageConstant
                                    //                             .imgHomeRed800,
                                    //                         height: getVerticalSize(16),
                                    //                         width:
                                    //                         getHorizontalSize(15)),
                                    //                     Spacer(flex: 34),
                                    //
                                    //                     CustomImageView(
                                    //                         svgPath: ImageConstant
                                    //                             .imgFile,
                                    //                         height: getVerticalSize(16),
                                    //                         width:
                                    //                         getHorizontalSize(15)),
                                    //
                                    //                     Spacer(flex: 34),
                                    //                     CustomImageView(
                                    //                         svgPath:
                                    //                         ImageConstant.imgMenuRed800,
                                    //                         height: getVerticalSize(16),
                                    //                         width:
                                    //                         getHorizontalSize(15)),
                                    //                     Spacer(flex: 30),
                                    //                     CustomImageView(
                                    //                         svgPath: ImageConstant
                                    //                             .imgUserRed800,
                                    //                         height: getVerticalSize(16),
                                    //                         width:
                                    //                         getHorizontalSize(15))
                                    //                   ])),
                                    //               Padding(
                                    //                   padding: getPadding(
                                    //                       left: 3,
                                    //                       top: 2,
                                    //                       right: 29,
                                    //                       bottom: 61),
                                    //                   child: Row(
                                    //                     children: [
                                    //                       GestureDetector(
                                    //                         onTap: () {
                                    //                           Navigator.pushReplacementNamed(context, '/home_page_screen');
                                    //                         },
                                    //                         child: Padding(
                                    //                           padding: getPadding(top: 2),
                                    //                           child: Text(
                                    //                             "lbl_home".tr,
                                    //                             overflow: TextOverflow.ellipsis,
                                    //                             textAlign: TextAlign.left,
                                    //                             style: AppStyle.txtMontserratSemiBold8Red800,
                                    //                           ),
                                    //                         ),
                                    //                       ),
                                    //                       Spacer(flex: 34),
                                    //
                                    //                       GestureDetector(
                                    //                         onTap: () {
                                    //                           // Navigate to the other screen
                                    //                           Navigator.push(
                                    //                             context,
                                    //                             MaterialPageRoute(builder: (context) => NotificationsPage()),
                                    //                           );
                                    //                         },
                                    //                         child: Padding(
                                    //                           padding: getPadding(top: 2),
                                    //                           child: Text(
                                    //                             "Notification".tr,
                                    //                             overflow: TextOverflow.ellipsis,
                                    //                             textAlign: TextAlign.left,
                                    //                             style: AppStyle.txtMontserratSemiBold8Red800,
                                    //                           ),
                                    //                         ),
                                    //                       ),
                                    //
                                    //                       Spacer(flex: 30),
                                    //                       GestureDetector(
                                    //                         onTap: () {
                                    //                           // Navigate to the other screen
                                    //                           Navigator.push(
                                    //                             context,
                                    //                             MaterialPageRoute(builder: (context) => CompatibilityPage()),
                                    //                           );
                                    //                         },
                                    //                         child: Padding(
                                    //                           padding: getPadding(top: 2),
                                    //                           child: Text(
                                    //                             "Compatibility".tr,
                                    //                             overflow: TextOverflow.ellipsis,
                                    //                             textAlign: TextAlign.left,
                                    //                             style: AppStyle.txtMontserratSemiBold8Red800,
                                    //                           ),
                                    //                         ),
                                    //                       ),
                                    //                       Spacer(flex: 29),
                                    //                       GestureDetector(
                                    //                         onTap: () {
                                    //                           Navigator.pushReplacementNamed(context, '/profile_screen');
                                    //                         },
                                    //                         child: Text(
                                    //                           "Profile".tr,
                                    //                           overflow: TextOverflow.ellipsis,
                                    //                           textAlign: TextAlign.left,
                                    //                           style: AppStyle.txtMontserratSemiBold8Red800,
                                    //                         ),
                                    //                       ),
                                    //                     ],
                                    //                   )
                                    //
                                    //               )])))
                                  ])))
                    ]))));
  }
}