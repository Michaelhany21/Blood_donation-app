import 'package:get/get.dart';

class HomePageItemModel {
  Rx<String> donationcentresOneTxt = Rx("msg_donation_centres".tr);

  Rx<String> requestTxt = Rx("lbl_request".tr);

  String? id = "";
}
