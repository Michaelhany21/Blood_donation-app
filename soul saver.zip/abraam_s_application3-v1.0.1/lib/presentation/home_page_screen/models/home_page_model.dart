import 'package:get/get.dart';
import 'home_page_item_model.dart';

class HomePageModel {
  RxList<HomePageItemModel> homePageItemList =
      RxList.generate(2, (index) => HomePageItemModel());
}
