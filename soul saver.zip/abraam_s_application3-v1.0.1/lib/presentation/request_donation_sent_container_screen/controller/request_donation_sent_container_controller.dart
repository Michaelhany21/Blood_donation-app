import 'package:soul_saver/core/app_export.dart';
import 'package:soul_saver/presentation/request_donation_sent_container_screen/models/request_donation_sent_container_model.dart';
// ignore: unused_import
import 'package:soul_saver/widgets/custom_bottom_bar.dart';

class RequestDonationSentContainerController extends GetxController {
  Rx<RequestDonationSentContainerModel> requestDonationSentContainerModelObj =
      RequestDonationSentContainerModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  
  @override
  void onInit() {
    super.onInit();
  }
}
