import '../controller/request_donation_sent_container_controller.dart';
import 'package:get/get.dart';

class RequestDonationSentContainerBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => RequestDonationSentContainerController());
  }
}
