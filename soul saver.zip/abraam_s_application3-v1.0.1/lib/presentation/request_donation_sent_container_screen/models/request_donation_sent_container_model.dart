class RequestDonationSentContainerModel {}
