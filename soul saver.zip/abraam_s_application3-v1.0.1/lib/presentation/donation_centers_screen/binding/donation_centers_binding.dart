import '../controller/donation_centers_controller.dart';
import 'package:get/get.dart';

class DonationCentersBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => DonationCentersController());
  }
}
