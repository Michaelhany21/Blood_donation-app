import 'package:soul_saver/core/app_export.dart';
import 'package:soul_saver/presentation/donation_centers_screen/models/donation_centers_model.dart';

class DonationCentersController extends GetxController {
  Rx<DonationCentersModel> donationCentersModelObj = DonationCentersModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
