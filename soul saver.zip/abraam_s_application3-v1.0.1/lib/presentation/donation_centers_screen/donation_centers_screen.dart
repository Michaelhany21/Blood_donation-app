import 'package:flutter/material.dart';
// import 'package:get/get.dart';
import 'package:url_launcher/url_launcher.dart';

// import '../../core/utils/image_constant.dart';
// import '../../core/utils/size_utils.dart';
// import '../../theme/app_style.dart';
// import '../../widgets/app_bar/appbar_image.dart';
// import '../../widgets/app_bar/appbar_title.dart';
// import '../../widgets/app_bar/custom_app_bar.dart';

class DonationCentersScreen extends StatelessWidget {
  final List<Map<String, String>> hospitals = [
    {
      'name': 'Ain Shams Specialized Hospital',
      'location': 'Abbasseya, Cairo',
      'phone': '0224853702',
      'website': 'https://goo.gl/maps/BHazD9AFKPhtHHuMA',
    },
    {
      'name': 'Cairo University Hospitals',
      'location': 'Giza, Cairo',
      'phone': '0223650139',
      'website': 'https://goo.gl/maps/Caoh3xTZ2MzRvdsb6',
    },
    {
      'name': 'Aswan Heart Centre',
      'location': 'Aswan, Aswan Governorate',
      'phone': '0972327345',
      'website': 'https://goo.gl/maps/eYqdK2j9C12R1MyS6',
    },
    {
      'name': 'Alexandria University Hospitals',
      'location': 'Azarita, Alexandria',
      'phone': '035906666',
      'website': 'https://goo.gl/maps/5qyRS821T3YrdRjo6',
    },
    {
      'name': 'Cleopatra Hospital',
      'location': 'Heliopolis, Cairo',
      'phone': '19767',
      'website': 'https://goo.gl/maps/fFXMU9wLgUwtBXV7A',
    },
  ];

  Future<void> _launchURL(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red[800],
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Text(
          "Donation Centers",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 20),
            ...hospitals.map((hospital) {
              return Card(
                margin: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                child: ListTile(
                  title: Text(
                    hospital['name']!,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 5),
                      Text(
                        hospital['location']!,
                      ),
                      SizedBox(height: 5),
                      Text(
                        hospital['phone']!,
                      ),
                    ],
                  ),
                  trailing: IconButton(
                    icon: Icon(Icons.public),
                    color: Colors.red,
                    onPressed: () {
                      _launchURL(hospital['website']!);
                    },
                  ),
                ),
              );
            }).toList(),
            SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
