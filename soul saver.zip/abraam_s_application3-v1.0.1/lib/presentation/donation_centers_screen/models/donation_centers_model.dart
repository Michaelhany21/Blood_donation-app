import 'package:get/get.dart';
import 'listcairocentralblo_one_item_model.dart';

class DonationCentersModel {
  RxList<ListcairocentralbloOneItemModel> listcairocentralbloOneItemList =
      RxList.generate(7, (index) => ListcairocentralbloOneItemModel());
}
