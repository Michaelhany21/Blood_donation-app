import 'package:get/get.dart';

class ListcairocentralbloOneItemModel {
  Rx<String> cairocentralbloOneTxt = Rx("msg_cairo_central_blood".tr);

  Rx<String> k257426672574491Txt = Rx("msg_25742667_25744915".tr);

  String? id = "";
}
