// ignore_for_file: unused_local_variable, unused_import, await_only_futures, unnecessary_statements, unused_element

import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:soul_saver/core/app_export.dart';
import 'package:soul_saver/core/utils/validation_functions.dart';
import 'package:soul_saver/presentation/home_page_screen/home_page_screen.dart';
import 'package:soul_saver/widgets/custom_button.dart';
import 'package:soul_saver/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class SignUpScreen extends StatefulWidget {
  @override
  _SignUpScreenState createState() => _SignUpScreenState();
}

var emaill, passwordd, namee;
bool _isHidden = true;

class _SignUpScreenState extends State<SignUpScreen> {
  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  void _togglePasswordView() {
    setState(() {
      _isHidden = !_isHidden;
    });
  }

  signup() async {
    var formdata = _formKey.currentState;
    if (formdata!.validate()) {
      formdata.save();
      try {
        showLoading(context);
        UserCredential usercredential =
            await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: emaill,
          password: passwordd,
          // userName: namee,
        );
        // if (usercredential.user!.emailVerified == false) {
        //   await FirebaseAuth.instance.currentUser!.sendEmailVerification();
        // }
        User? user = usercredential.user;
        await user?.updateDisplayName(namee);
        await user?.reload();
        //await user?.updatePhoneNumber(phonee);

        return usercredential;

        // ignore: dead_code
        await user?.reload();
      } on FirebaseAuthException catch (e) {
        if (e.code == 'weak-password') {
          Navigator.of(context).canPop;
          AwesomeDialog(
              context: context,
              title: "Error",
              body: Text("Password is to weak"))
            ..show();

          print('The password provided is too weak');
        } else if (e.code == 'email-already-in-use') {
          Navigator.of(context).canPop();
          AwesomeDialog(
              context: context,
              title: "Error",
              body: Text("The account already exists for that email"))
            ..show();
          // print('The account already exists for that email');
        }
      } catch (e) {
        // Navigator.of(context).canPop();
        print(e);
      }
    } else {
      Navigator.of(context).canPop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: ColorConstant.whiteA700,
        body: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Container(
              width: double.maxFinite,
              padding: EdgeInsets.fromLTRB(22, 82, 22, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Padding(
                    padding: EdgeInsets.only(left: 11),
                    child: Text(
                      "lbl_sign_up".tr,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtMontserratBold24,
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(left: 11, top: 1),
                    child: Text(
                      "msg_please_register".tr,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: AppStyle.txtSegoeUI14,
                    ),
                  ),
                  Container(
                    alignment: Alignment.center,
                    padding:
                        const EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                    decoration: const BoxDecoration(),
                    child: TextFormField(
                      onSaved: (val) {
                        namee = val;
                      },
                      validator: (val) {
                        if (val!.length > 100) {
                          return "username can't be larger than 100 letter";
                        }
                        if (val.length < 2) {
                          return "username can't be less than 2 letter";
                        }
                        return null;
                      },
                      style: TextStyle(color: Colors.black),
                      controller: nameController,
                      keyboardType: TextInputType.name,
                      decoration: const InputDecoration(
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: Colors.black,
                              width: 2,
                            ),
                            //   borderRadius:
                            //       BorderRadius.all(Radius.circular(20)),
                          ),
                          hintStyle: TextStyle(color: Colors.black),
                          hintText: "User Name",
                          border: InputBorder.none),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Container(
                    alignment: Alignment.center,
                    padding:
                        const EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                    decoration: const BoxDecoration(),
                    child: TextFormField(
                      onSaved: (val) {
                        emaill = val;
                      },
                      validator: (val) {
                        if (val!.length > 100) {
                          return "email can't be larger than 100 letter";
                        }
                        if (val.length < 2) {
                          return "email can't be less than 2 letter";
                        }
                        return null;
                      },
                      style: TextStyle(color: Colors.black),
                      controller: emailController,
                      keyboardType: TextInputType.emailAddress,
                      decoration: const InputDecoration(
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: Colors.grey,
                              width: 2,
                            ),
                            // borderRadius:
                            //     BorderRadius.all(Radius.circular(20)),
                          ),
                          hintText: "Email",
                          hintStyle: TextStyle(color: Colors.black),
                          border: InputBorder.none),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Container(
                    alignment: Alignment.center,
                    padding:
                        const EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                    decoration: const BoxDecoration(),
                    child: TextFormField(
                      onSaved: (val) {
                        passwordd = val;
                      },
                      validator: (val) {
                        if (val!.length > 100) {
                          return "password can't be larger than 100 letter";
                        }
                        if (val.length < 2) {
                          return "password can't be less than 2 letter";
                        }
                        return null;
                      },
                      style: TextStyle(color: Colors.black),
                      controller: passwordController,
                      keyboardType: TextInputType.visiblePassword,
                      textInputAction: TextInputAction.done,
                      obscureText: _isHidden,
                      decoration: InputDecoration(
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: Colors.black,
                              width: 2,
                            ),
                            // borderRadius:
                            //     BorderRadius.all(Radius.circular(20)),
                          ),
                          hintText: " PassWord",
                          suffixIcon: InkWell(
                            onTap: _togglePasswordView,
                            child: Icon(
                              _isHidden
                                  ? Icons.visibility_off
                                  : Icons.visibility,
                              color: Colors.red,
                            ),
                          ),
                          hintStyle: TextStyle(color: Colors.black),
                          border: InputBorder.none),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Container(
                    alignment: Alignment.center,
                    padding:
                        const EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                    decoration: const BoxDecoration(),
                    child: TextFormField(
                      onSaved: (val) {
                        passwordd = val;
                      },
                      validator: (val) {
                        if (val!.length > 100) {
                          return "confirm_password can't be larger than 100 letter";
                        }
                        if (val.length < 2) {
                          return "confirm_password can't be less than 2 letter";
                        }
                        return null;
                      },
                      style: TextStyle(color: Colors.black),
                      controller: confirmPasswordController,
                      onChanged: (value) =>
                          _isHidden ? passwordController : null,
                      keyboardType: TextInputType.visiblePassword,
                      // obscureText: true,
                      decoration: const InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: Colors.black,
                            width: 2,
                          ),
                          // borderRadius:
                          //     BorderRadius.all(Radius.circular(25)),
                        ),
                        hintText: "confirm_password",
                        hintStyle: TextStyle(color: Colors.black),
                        border: InputBorder.none,
                      ),
                      obscureText: _isHidden,
                    ),
                  ),
                  // CustomTextFormField(
                  //   onSaved: (val) {
                  //     namee = val;
                  //   },
                  //   focusNode: FocusNode(),
                  //   controller: nameController,
                  //   hintText: "lbl_name".tr,
                  //   margin: EdgeInsets.only(top: 20),
                  //   fontStyle: TextFormFieldFontStyle.MontserratRegular14,
                  //   validator: (val) {
                  //     if (val!.length > 100) {
                  //       return "username can't be larger than 100 letter";
                  //     }
                  //     if (val.length < 2) {
                  //       return "username can't be less than 2 letter";
                  //     }
                  //     return null;
                  //   },
                  //   // validator: (value) {
                  //   //   // if (!isText(value)) {
                  //   //   //   return "Please enter valid text";
                  //   //   // }
                  //   //   // return null;
                  //   // },
                  // ),
                  // CustomTextFormField(
                  //   focusNode: FocusNode(),
                  //   controller: emailController,
                  //   hintText: "lbl_email".tr,
                  //   margin: EdgeInsets.only(top: 37),
                  //   fontStyle: TextFormFieldFontStyle.MontserratRegular14,
                  //   textInputType: TextInputType.emailAddress,
                  //   validator: (val) {
                  //     if (val!.length > 100) {
                  //       return "email can't be larger than 100 letter";
                  //     }
                  //     if (val.length < 2) {
                  //       return "email can't be less than 2 letter";
                  //     }
                  //     return null;
                  //   },
                  //   // validator: (value) {
                  //   //   if (value == null ||
                  //   //       (!isValidEmail(value, isRequired: true))) {
                  //   //     return "Please enter valid email";
                  //   //   }
                  //   //   return null;
                  //   // },
                  //   onSaved: (val) {
                  //     emaill = val;
                  //   },
                  // ),
                  // CustomTextFormField(
                  //   isObscureText: _isHidden,
                  //   focusNode: FocusNode(),
                  // //    decoration: InputDecoration(
                  // //   hintText: "Password",
                  // //   suffixIcon: InkWell(
                  // //                 onTap: _togglePasswordView,
                  // //                 child: Icon(
                  // //                   _isHidden
                  // //                       ? Icons.visibility
                  // //                       : Icons.visibility_off,
                  // //                   color: Colors.red,
                  // //                 ),
                  // //               ),
                  // // ),
                  //   controller: passwordController,
                  //   hintText: "lbl_password2".tr,
                  //   margin: EdgeInsets.only(top: 34),
                  //   fontStyle: TextFormFieldFontStyle.MontserratRegular14,
                  //   textInputType: TextInputType.visiblePassword,
                  //   validator: (val) {
                  //     if (val!.length > 100) {
                  //       return "password can't be larger than 100 letter";
                  //     }
                  //     if (val.length < 2) {
                  //       return "password can't be less than 2 letter";
                  //     }
                  //     return null;
                  //   },
                  //   // validator: (value) {
                  //   //   if (value == null) {
                  //   //       // (!isValidPassword(value, isRequired: true))

                  //   //     return "Please enter valid password";
                  //   //   }
                  //   //   return null;
                  //   // },
                  //   onSaved: (val) {
                  //     passwordd = val;
                  //   },

                  // ),
                  // CustomTextFormField(
                  //   focusNode: FocusNode(),
                  //   controller: confirmPasswordController,
                  //   hintText: "msg_confirm_password".tr,
                  //   margin: EdgeInsets.only(top: 37),
                  //   fontStyle: TextFormFieldFontStyle.MontserratRegular14,
                  //   textInputAction: TextInputAction.done,
                  //   textInputType: TextInputType.visiblePassword,
                  //   // validator: (value) {
                  //   //   if (value == null  ) {//||(!isValidPassword(value, isRequired: true))

                  //   //     return "Please enter valid password";
                  //   //   }
                  //   //   return null;
                  //   // },
                  //   validator: (val) {
                  //     if (val!.length > 100) {
                  //       return "password can't be larger than 100 letter";
                  //     }
                  //     if (val.length < 2) {
                  //       return "password can't be less than 2 letter";
                  //     }
                  //     return null;
                  //   },
                  //   onSaved: (val) {
                  //     passwordd = val;
                  //   },
                  //   isObscureText: _isHidden,
                  // ),
                  CustomButton(
                    height: getVerticalSize(57),
                    text: "lbl_sign_up".tr,
                    margin: EdgeInsets.only(top: 65, bottom: 5),
                    shape: ButtonShape.RoundedBorder10,
                    padding: ButtonPadding.PaddingAll19,
                    fontStyle: ButtonFontStyle.MontserratSemiBold14,
                    onTap: () async {
                      UserCredential responses = await signup();
                      print("===================");
                      // ignore: unnecessary_null_comparison
                      if (responses != null) {
                        await FirebaseFirestore.instance
                            .collection("users")
                            .add({
                          "userName": namee,
                          "email": emaill,
                        });
                        Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                              builder: (context) => HomePageScreen(),
                            ));
                      } else {
                        print("Sign Up Faild");
                      }
                      print("===================");
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
        bottomNavigationBar: Padding(
          padding: EdgeInsets.only(left: 69, right: 75, bottom: 39),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "msg_already_have_an".tr,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.left,
                style: AppStyle.txtMontserratRegular14,
              ),
              GestureDetector(
                onTap: () {
                  navigateToLoginScreen();
                },
                child: Padding(
                  padding: EdgeInsets.only(left: 2),
                  child: Text(
                    "lbl_log_in".tr,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.left,
                    style: AppStyle.txtMontserratSemiBold14,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // void signUpUser() {
  //   // TODO: Implement sign-up logic using email and password

  //   String name = nameController.text;
  //   String email = emailController.text;
  //   String password = passwordController.text;

  //   // Here, you can integrate with a database and store the user's information
  //   // You can use the 'name', 'email', and 'password' variables to store the data in the database

  //   // After successful sign-up, navigate to the login screen
  //   navigateToLoginScreen();
  // }

  void navigateToLoginScreen() {
    Navigator.pushReplacementNamed(context, AppRoutes.logInScreen);
  }
}

showLoading(context) {
  return showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text("Please Wait"),
          content: Container(
              height: 50,
              child: Center(
                child: CircularProgressIndicator(
                  color: Colors.red,
                  backgroundColor: Colors.grey,
                ),
              )),
        );
      });
}
