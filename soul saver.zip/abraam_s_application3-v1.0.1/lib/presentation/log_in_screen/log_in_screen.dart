// ignore_for_file: unused_field, unused_element

import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:flutter/material.dart';
import 'package:soul_saver/presentation/sign_up_screen/sign_up_screen.dart';

//import '../../database/db_test.dart';
import '../home_page_screen/home_page_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';

class LogInScreen extends StatefulWidget {
  @override
  _LogInScreenState createState() => _LogInScreenState();
}

class _LogInScreenState extends State<LogInScreen> {
  // TextEditingController usernameController = TextEditingController();
  // TextEditingController passwordController = TextEditingController();
  bool _isHidden = true;
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  void _togglePasswordView() {
    setState(() {
      _isHidden = !_isHidden;
    });
  }

  // DatabaseHelper databaseHelper = DatabaseHelper();
  signin() async {
    var formdata = _formKey.currentState;
    if (formdata!.validate()) {
      formdata.save();
      try {
        showLoading(context);
        UserCredential userCredential = await FirebaseAuth.instance
            .signInWithEmailAndPassword(
                email: emaill.toString().trim(),
                password: passwordd.toString().trim());
        return userCredential;
      } on FirebaseAuthException catch (e) {
        if (e.code == 'user-not-found') {
          Navigator.of(context).canPop();
          AwesomeDialog(
              context: context,
              title: "Error",
              body: Text("No user found for that email"))
            ..show();
        } else if (e.code == 'wrong-password') {
          Navigator.of(context).canPop();
          AwesomeDialog(
              context: context,
              title: "Error",
              body: Text("Wrong password provided for that user"))
            ..show();
        }
      }
    } else {
      print("Not Vaild");
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.white,
        body: Form(
          key: _formKey,
          child: Container(
            width: double.maxFinite,
            padding: EdgeInsets.fromLTRB(22, 39, 22, 39),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Padding(
                  padding: EdgeInsets.only(top: 107),
                  child: Text(
                    "Welcome",
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 24,
                      color: Colors.red,
                      fontFamily: 'Montserrat',
                    ),
                  ),
                ),
                TextFormField(
                  onSaved: (val) {
                    emaill = val;
                  },
                  //controller: usernameController,
                  decoration: InputDecoration(
                    hintText: "Username",
                  ),
                  validator: (val) {
                    if (val!.length > 100) {
                      return "email can't be larger than 100 letter";
                    }
                    if (val.length < 2) {
                      return "email can't be less than 2 letter";
                    }
                    return null;
                  },
                  // validator: (value) {
                  //   if (value != "hi") {
                  //     return "Invalid username";
                  //   }
                  //   return null;
                  // },
                  style: TextStyle(
                    fontFamily: 'Montserrat',
                  ),
                ),
                TextFormField(
                  onSaved: (val) {
                    passwordd = val;
                  },

                  //controller: passwordController,
                  decoration: InputDecoration(
                    hintText: "Password",
                    suffixIcon: InkWell(
                      onTap: _togglePasswordView,
                      child: Icon(
                        _isHidden ? Icons.visibility : Icons.visibility_off,
                        color: Colors.red,
                      ),
                    ),
                  ),
                  obscureText: _isHidden,

                  validator: (val) {
                    if (val!.length > 100) {
                      return "password can't be larger than 100 letter";
                    }
                    if (val.length < 2) {
                      return "password can't be less than 2 letter";
                    }
                    return null;
                  },
                  // validator: (value) {
                  //   if (value != "1234") {
                  //     return "Invalid password";
                  //   }
                  //   return null;
                  // },
                  style: TextStyle(
                    fontFamily: 'Montserrat',
                  ),
                ),
                ElevatedButton(
                  onPressed: () async {
                    var user = await signin();
                    if (user != null) {
                      Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => HomePageScreen(),
                          ));
                    } else {
                      // print("Login Faild");
                    }
                  },
                  child: Text("Log In"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(top: 23),
                  child: Column(
                    children: [
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          "don't have an account?",
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey[800],
                            fontFamily: 'SegueUI',
                          ),
                        ),
                      ),
                      ElevatedButton(
                        onPressed: () {

                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                              builder: (context) => SignUpScreen(),
                            ),
                          );
                        },
                        child: Text(
                          "Sign Up",
                          style: TextStyle(
                            color: Colors.white,
                            fontFamily: 'Montserrat',
                          ),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

//   void loginUser() async {
//     // String username = usernameController.text;
//     // String password = passwordController.text;

//     Map<String, dynamic>? user =
//         await databaseHelper.getUser(username, password);

//     if (user != null) {
//       // Successful login
//       print('Logged in successfully!');
//       Navigator.pushReplacement(
//         context,
//         MaterialPageRoute(builder: (context) => HomePageScreen()),
//       );
//     } else {
//       // Invalid credentials
//       print('Invalid username or password');
//       // Add your code for handling invalid credentials
//     }
//   }
// }
}
