import 'package:soul_saver/core/app_export.dart';
import 'package:soul_saver/presentation/contact_donor_screen/models/contact_donor_model.dart';

class ContactDonorController extends GetxController {
  Rx<ContactDonorModel> contactDonorModelObj = ContactDonorModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
