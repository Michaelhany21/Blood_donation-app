class ContactDonorModel {}
