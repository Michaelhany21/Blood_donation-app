import 'controller/contact_donor_controller.dart';
import 'package:soul_saver/core/app_export.dart';
import 'package:soul_saver/widgets/app_bar/appbar_image.dart';
import 'package:soul_saver/widgets/app_bar/appbar_title.dart';
import 'package:soul_saver/widgets/app_bar/custom_app_bar.dart';
import 'package:soul_saver/widgets/custom_button.dart';
import 'package:flutter/material.dart';

class ContactDonorScreen extends GetWidget<ContactDonorController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
           // backgroundColor: ColorConstant.gray400,
            body:SingleChildScrollView(
            child: Container(
                height: size.height,
                width: double.maxFinite,
                child: Stack(alignment: Alignment.bottomLeft, children: [
                  Align(
                      alignment: Alignment.center,
                      child: Container(
                          decoration: AppDecoration.fillRed800,
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                CustomAppBar(
                                    height: getVerticalSize(43),
                                    leadingWidth: 39,
                                    leading: AppbarImage(
                                        height: getVerticalSize(11),
                                        width: getHorizontalSize(7),
                                        svgPath:
                                            ImageConstant.imgArrowleftWhiteA700,
                                        margin: getMargin(
                                            left: 32, top: 9, bottom: 3),
                                        onTap: onTapArrowleft3),
                                    title: AppbarTitle(
                                        text: "lbl_donor_s_list2".tr,
                                        margin: getMargin(left: 14))),
                                Padding(
                                    padding: getPadding(left: 32, top: 11),
                                    child: Text("msg_select_from_the".tr,
                                        overflow: TextOverflow.ellipsis,
                                        textAlign: TextAlign.left,
                                        style:
                                            AppStyle.txtMontserratSemiBold12)),
                                Container(
                                    width: double.maxFinite,
                                    child: Container(
                                        margin: getMargin(top: 17),
                                        padding: getPadding(
                                            left: 28,
                                            top: 32,
                                            right: 28,
                                            bottom: 32),
                                        decoration: AppDecoration.fillWhiteA700
                                            .copyWith(
                                                borderRadius: BorderRadiusStyle
                                                    .customBorderTL30),
                                        child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              Padding(
                                                  padding: getPadding(
                                                      left: 8, top: 4),
                                                  child: Text(
                                                      "lbl_wunmi_tunde".tr,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtMontserratSemiBold14Black900)),
                                              Padding(
                                                  padding: getPadding(
                                                      top: 13, right: 5),
                                                  child: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Expanded(
                                                            child: CustomButton(
                                                                height:
                                                                    getVerticalSize(
                                                                        34),
                                                                text: "lbl_call"
                                                                    .tr,
                                                                margin: getMargin(
                                                                    right:
                                                                        19))),
                                                        Expanded(
                                                            child: CustomButton(
                                                                height:
                                                                    getVerticalSize(
                                                                        34),
                                                                text:
                                                                    "lbl_message"
                                                                        .tr,
                                                                margin:
                                                                    getMargin(
                                                                        left:
                                                                            19),
                                                                variant:
                                                                    ButtonVariant
                                                                        .OutlineRed800,
                                                                fontStyle:
                                                                    ButtonFontStyle
                                                                        .MontserratSemiBold12Gray800))
                                                      ])),

                                              Padding(
                                                  padding: getPadding(
                                                      left: 8, top: 27),
                                                  child: Text(
                                                      "lbl_wunmi_tunde".tr,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtMontserratSemiBold14Black900)),
                                              Padding(
                                                  padding: getPadding(
                                                      top: 13, right: 5),
                                                  child: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Expanded(
                                                            child: CustomButton(
                                                                height:
                                                                    getVerticalSize(
                                                                        34),
                                                                text: "lbl_call"
                                                                    .tr,
                                                                margin: getMargin(
                                                                    right:
                                                                        19))),
                                                        Expanded(
                                                            child: CustomButton(
                                                                height:
                                                                    getVerticalSize(
                                                                        34),
                                                                text:
                                                                    "lbl_message"
                                                                        .tr,
                                                                margin:
                                                                    getMargin(
                                                                        left:
                                                                            19),
                                                                variant:
                                                                    ButtonVariant
                                                                        .OutlineRed800,
                                                                fontStyle:
                                                                    ButtonFontStyle
                                                                        .MontserratSemiBold12Gray800))
                                                      ])),
                                              Padding(
                                                  padding: getPadding(
                                                      left: 8, top: 32),
                                                  child: Text(
                                                      "lbl_wunmi_tunde".tr,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtMontserratSemiBold14Black900)),
                                              Padding(
                                                  padding: getPadding(
                                                      top: 13, right: 5),
                                                  child: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Expanded(
                                                            child: CustomButton(
                                                                height:
                                                                    getVerticalSize(
                                                                        34),
                                                                text: "lbl_call"
                                                                    .tr,
                                                                margin: getMargin(
                                                                    right:
                                                                        19))),
                                                        Expanded(
                                                            child: CustomButton(
                                                                height:
                                                                    getVerticalSize(
                                                                        34),
                                                                text:
                                                                    "lbl_message"
                                                                        .tr,
                                                                margin:
                                                                    getMargin(
                                                                        left:
                                                                            19),
                                                                variant:
                                                                    ButtonVariant
                                                                        .OutlineRed800,
                                                                fontStyle:
                                                                    ButtonFontStyle
                                                                        .MontserratSemiBold12Gray800))
                                                      ])),
                                              Padding(
                                                  padding: getPadding(
                                                      left: 8, top: 27),
                                                  child: Text(
                                                      "lbl_wunmi_tunde".tr,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtMontserratSemiBold14Black900)),
                                              Padding(
                                                  padding: getPadding(
                                                      top: 13, right: 5),
                                                  child: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Expanded(
                                                            child: CustomButton(
                                                                height:
                                                                    getVerticalSize(
                                                                        34),
                                                                text: "lbl_call"
                                                                    .tr,
                                                                margin:
                                                                    getMargin(
                                                                        right:
                                                                            19),
                                                                variant:
                                                                    ButtonVariant
                                                                        .OutlineRed800,
                                                                fontStyle:
                                                                    ButtonFontStyle
                                                                        .MontserratSemiBold12Red800)),
                                                        Expanded(
                                                            child: CustomButton(
                                                                height:
                                                                    getVerticalSize(
                                                                        34),
                                                                text:
                                                                    "lbl_message"
                                                                        .tr,
                                                                margin:
                                                                    getMargin(
                                                                        left:
                                                                            19)))
                                                      ])),
                                              Padding(
                                                  padding: getPadding(
                                                      left: 8, top: 22),
                                                  child: Text(
                                                      "lbl_wunmi_tunde".tr,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtMontserratSemiBold14Black900)),
                                              Padding(
                                                  padding: getPadding(
                                                      top: 13, right: 5),
                                                  child: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Expanded(
                                                            child: CustomButton(
                                                                height:
                                                                    getVerticalSize(
                                                                        34),
                                                                text: "lbl_call"
                                                                    .tr,
                                                                margin: getMargin(
                                                                    right:
                                                                        19))),
                                                        Expanded(
                                                            child: CustomButton(
                                                                height:
                                                                    getVerticalSize(
                                                                        34),
                                                                text:
                                                                    "lbl_message"
                                                                        .tr,
                                                                margin:
                                                                    getMargin(
                                                                        left:
                                                                            19),
                                                                variant:
                                                                    ButtonVariant
                                                                        .OutlineRed800,
                                                                fontStyle:
                                                                    ButtonFontStyle
                                                                        .MontserratSemiBold12Gray800))
                                                      ])),
                                              Padding(
                                                  padding: getPadding(
                                                      left: 8, top: 27),
                                                  child: Text(
                                                      "lbl_wunmi_tunde".tr,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign: TextAlign.left,
                                                      style: AppStyle
                                                          .txtMontserratSemiBold14Black900))
                                            ])))
                              ]))),
                  CustomButton(
                      height: getVerticalSize(34),
                      width: getHorizontalSize(138),
                      text: "lbl_call".tr,
                      margin: getMargin(left: 28),
                      variant: ButtonVariant.OutlineRed800,
                      fontStyle: ButtonFontStyle.MontserratSemiBold12Red800,
                      alignment: Alignment.bottomLeft),
                  CustomButton(
                      height: getVerticalSize(34),
                      width: getHorizontalSize(138),
                      text: "lbl_message".tr,
                      margin: getMargin(right: 33),
                      alignment: Alignment.bottomRight)
                ])))));
  }

  onTapArrowleft3() {
    Get.back();
  }
}
