import '../controller/contact_donor_controller.dart';
import 'package:get/get.dart';

class ContactDonorBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => ContactDonorController());
  }
}
