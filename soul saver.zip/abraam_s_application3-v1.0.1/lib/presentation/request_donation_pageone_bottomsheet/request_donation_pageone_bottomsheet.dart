import 'controller/request_donation_pageone_controller.dart';
import 'package:soul_saver/core/app_export.dart';
import 'package:soul_saver/core/utils/validation_functions.dart';
import 'package:soul_saver/widgets/custom_button.dart';
import 'package:soul_saver/widgets/custom_drop_down.dart';
import 'package:soul_saver/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class RequestDonationPageoneBottomsheet extends StatelessWidget {
  RequestDonationPageoneBottomsheet(this.controller);

  RequestDonationPageoneController controller;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
        child: Container(
            width: double.maxFinite,
            child: Container(
                width: double.maxFinite,
                padding: getPadding(top: 1, bottom: 1),
                decoration: AppDecoration.fillWhiteA700
                    .copyWith(borderRadius: BorderRadiusStyle.customBorderTL30),
                child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      CustomDropDown(
                          focusNode: FocusNode(),
                          icon: Container(
                              margin: getMargin(left: 30, right: 48),
                              decoration: BoxDecoration(
                                  border: Border.all(
                                      color: ColorConstant.gray900,
                                      width: getHorizontalSize(2),
                                      strokeAlign: BorderSide.strokeAlignCenter)),
                              child: CustomImageView(
                                  svgPath: ImageConstant.imgArrowdown)),
                          hintText: "lbl_genotype".tr,
                          margin: getMargin(left: 22, top: 56, right: 22),
                          items: controller.requestDonationPageoneModelObj.value
                              .dropdownItemList,
                          onChanged: (value) {
                            controller.onSelected(value);
                          }),
                      CustomDropDown(
                          focusNode: FocusNode(),
                          icon: Container(
                              margin: getMargin(left: 30, right: 48),
                              decoration: BoxDecoration(
                                  border: Border.all(
                                      color: ColorConstant.gray900,
                                      width: getHorizontalSize(2),
                                      strokeAlign: BorderSide.strokeAlignCenter)),
                              child: CustomImageView(
                                  svgPath: ImageConstant.imgArrowdown)),
                          hintText: "lbl_blood_group".tr,
                          margin: getMargin(left: 22, top: 37, right: 22),
                          items: controller.requestDonationPageoneModelObj.value
                              .dropdownItemList1,
                          onChanged: (value) {
                            controller.onSelected1(value);
                          }),
                      CustomTextFormField(
                          focusNode: FocusNode(),
                          controller: controller.groupninetytwoController,
                          hintText: "lbl_time_needed".tr,
                          margin: getMargin(left: 22, top: 34, right: 22),
                          fontStyle:
                              TextFormFieldFontStyle.MontserratRegular14),
                      CustomTextFormField(
                          focusNode: FocusNode(),
                          controller: controller.groupfiftysixController,
                          hintText: "msg_institution_name".tr,
                          margin: getMargin(left: 22, top: 37, right: 22),
                          fontStyle: TextFormFieldFontStyle.MontserratRegular14,
                          textInputAction: TextInputAction.done,
                          validator: (value) {
                            if (!isText(value)) {
                              return "Please enter valid text";
                            }
                            return null;
                          }),
                      CustomButton(
                          height: getVerticalSize(57),
                          text: "lbl_request".tr,
                          margin: getMargin(left: 22, top: 65, right: 22),
                          shape: ButtonShape.RoundedBorder10,
                          padding: ButtonPadding.PaddingAll19,
                          fontStyle: ButtonFontStyle.MontserratSemiBold14,
                          onTap: onTapRequest),
                      Spacer(),
                      Container(
                          height: getVerticalSize(45),
                          width: double.maxFinite,
                          decoration: AppDecoration.fillWhiteA700,
                          child: Stack(alignment: Alignment.topLeft, children: [
                            CustomImageView(
                                svgPath: ImageConstant.imgRectangle88stroke,
                                height: getVerticalSize(45),
                                width: getHorizontalSize(375),
                                alignment: Alignment.bottomCenter),
                            Align(
                                alignment: Alignment.topLeft,
                                child: Padding(
                                    padding: getPadding(left: 50, top: 5),
                                    child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Padding(
                                              padding:
                                                  getPadding(left: 3, right: 3),
                                              child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgHomeGray60001,
                                                        height: getSize(13),
                                                        width: getSize(13),
                                                        margin: getMargin(
                                                            bottom: 2)),
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgMenuGray600,
                                                        height: getSize(15),
                                                        width: getSize(15),
                                                        margin: getMargin(
                                                            left: 104, top: 1)),
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgUserGray600,
                                                        height: getSize(13),
                                                        width: getSize(13),
                                                        margin: getMargin(
                                                            left: 105,
                                                            bottom: 2),
                                                        onTap: () {
                                                          onTapImgUser();
                                                        })
                                                  ])),
                                          Padding(
                                              padding: getPadding(top: 3),
                                              child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgHomeGray600015x20,
                                                        height:
                                                            getVerticalSize(5),
                                                        width:
                                                            getHorizontalSize(
                                                                20),
                                                        margin:
                                                            getMargin(top: 2)),
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgNotifications,
                                                        height:
                                                            getVerticalSize(5),
                                                        width:
                                                            getHorizontalSize(
                                                                43),
                                                        margin: getMargin(
                                                            left: 86,
                                                            bottom: 2)),
                                                    CustomImageView(
                                                        svgPath: ImageConstant
                                                            .imgProfileGray600,
                                                        height:
                                                            getVerticalSize(5),
                                                        width:
                                                            getHorizontalSize(
                                                                21),
                                                        margin: getMargin(
                                                            left: 87,
                                                            bottom: 1))
                                                  ]))
                                        ])))
                          ]))
                    ]))));
  }

  onTapRequest() {
    Get.toNamed(AppRoutes.requestDonationSentContainerScreen);
  }

  onTapImgUser() {
    Get.toNamed(AppRoutes.profileScreen);
  }
}
