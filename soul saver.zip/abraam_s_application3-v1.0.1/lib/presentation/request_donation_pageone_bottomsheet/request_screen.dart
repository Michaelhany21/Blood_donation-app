import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import '../home_page_screen/home_page_screen.dart';

class RequestScreen extends StatefulWidget {
  @override
  _RequestScreenState createState() => _RequestScreenState();
}

class _RequestScreenState extends State<RequestScreen> {
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  User? user;
  final bloodTypeController = TextEditingController();
  final timeNeededController = TextEditingController();
  final institutionNameController = TextEditingController();
  FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;

  @override
  void initState() {
    super.initState();
    initUser();
    _configureFirebaseMessaging();
  }

  Future<void> initUser() async {
    final userData = FirebaseAuth.instance.currentUser;
    setState(() {
      user = userData;
    });
  }

  void _configureFirebaseMessaging() {
    _firebaseMessaging.requestPermission(
      sound: true,
      badge: true,
      alert: true,
      provisional: false,
    );
    _firebaseMessaging.getToken().then((token) {
      print('FCM Token: $token');
    });
  }

  void sendNotificationToUser(String deviceToken, String title, String body) async {
    final postUrl = 'https://fcm.googleapis.com/fcm/send';
    final headers = <String, String>{
      'Content-Type': 'application/json',
      'Authorization': 'key=<YOUR_FCM_SERVER_KEY>',
    };

    final data = <String, dynamic>{
      'notification': <String, dynamic>{
        'body': body,
        'title': title,
        'sound': 'default',
      },
      'priority': 'high',
      'data': <String, dynamic>{
        'click_action': 'FLUTTER_NOTIFICATION_CLICK',
        'id': '1',
        'status': 'done',
      },
      'to': deviceToken,
    };

    final response = await http.post(
      Uri.parse(postUrl),
      body: json.encode(data),
      encoding: Encoding.getByName('utf-8'),
      headers: headers,
    );

    if (response.statusCode == 200) {
      print('Notification sent successfully.');
    } else {
      print('Error sending notification: ${response.body}');
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.red[800],
        appBar: AppBar(
          backgroundColor: Colors.red[800],
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          title: Text(
            "Request Detail",
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 20,
            ),
          ),
        ),
        body: Padding(
          padding: EdgeInsets.all(22),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Please enter your details",
                  style: TextStyle(
                    fontSize: 13,
                  ),
                ),
                SizedBox(height: 19),
                Container(
                  padding: EdgeInsets.all(22),
                  decoration: BoxDecoration(
                    color: Colors.grey[50],
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: Column(
                    children: [
                      TextFormField(
                        controller: bloodTypeController,
                        decoration: InputDecoration(
                          hintText: "Blood Type",
                        ),
                        validator: (value) {
                          if (value?.isEmpty ?? true) {
                            return "Please enter blood type";
                          }
                          return null;
                        },
                      ),
                      SizedBox(height: 37),
                      TextFormField(
                        controller: timeNeededController,
                        decoration: InputDecoration(
                          hintText: "Time Needed",
                        ),
                        validator: (value) {
                          if (value?.isEmpty ?? true) {
                            return "Please enter time needed";
                          }
                          return null;
                        },
                      ),
                      SizedBox(height: 37),
                      TextFormField(
                        controller: institutionNameController,
                        decoration: InputDecoration(
                          hintText: "Institution Name",
                        ),
                        validator: (value) {
                          if (value?.isEmpty ?? true) {
                            return "Please enter institution name";
                          }
                          return null;
                        },
                      ),
                      SizedBox(height: 37),
                      ElevatedButton(
                        onPressed: () async {
                          if (_formKey.currentState?.validate() ?? false) {
                            CollectionReference collRef =
                            FirebaseFirestore.instance.collection('Requests');
                            DocumentReference docRef = await collRef.add({
                              'bloodType': bloodTypeController.text,
                              'timeNeeded': timeNeededController.text,
                              'institutionName': institutionNameController.text,
                            });

                            String title = 'New Request';
                            String body = 'A new request has been added.';
                            QuerySnapshot devicesSnapshot = await FirebaseFirestore.instance.collection('Devices').get();
                            devicesSnapshot.docs.forEach((doc) {
                              sendNotificationToUser(doc['deviceToken'], title, body);
                            });

                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => HomePageScreen(),
                              ),
                            );
                          }
                        },
                        style: ElevatedButton.styleFrom(
                          primary: Colors.red[800],
                          padding: EdgeInsets.symmetric(
                            vertical: 15,
                            horizontal: 20,
                          ),
                        ),
                        child: Text(
                          "Enter",
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 14,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
