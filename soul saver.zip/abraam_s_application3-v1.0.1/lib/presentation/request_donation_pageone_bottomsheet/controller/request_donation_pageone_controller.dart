import 'package:soul_saver/core/app_export.dart';
import 'package:soul_saver/presentation/request_donation_pageone_bottomsheet/models/request_donation_pageone_model.dart';
import 'package:flutter/material.dart';

class RequestDonationPageoneController extends GetxController {
  TextEditingController groupninetytwoController = TextEditingController();

  TextEditingController groupfiftysixController = TextEditingController();

  Rx<RequestDonationPageoneModel> requestDonationPageoneModelObj =
      RequestDonationPageoneModel().obs;

  SelectionPopupModel? selectedDropDownValue;

  SelectionPopupModel? selectedDropDownValue1;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
    groupninetytwoController.dispose();
    groupfiftysixController.dispose();
  }

  onSelected(dynamic value) {
    selectedDropDownValue = value as SelectionPopupModel;
    requestDonationPageoneModelObj.value.dropdownItemList.forEach((element) {
      element.isSelected = false;
      if (element.id == value.id) {
        element.isSelected = true;
      }
    });
    requestDonationPageoneModelObj.value.dropdownItemList.refresh();
  }

  onSelected1(dynamic value) {
    selectedDropDownValue1 = value as SelectionPopupModel;
    requestDonationPageoneModelObj.value.dropdownItemList1.forEach((element) {
      element.isSelected = false;
      if (element.id == value.id) {
        element.isSelected = true;
      }
    });
    requestDonationPageoneModelObj.value.dropdownItemList1.refresh();
  }
}
