import 'package:soul_saver/presentation/log_in_screen/log_in_screen.dart';
import 'package:soul_saver/presentation/profile_screen/about_app_screen.dart';

import 'controller/profile_controller.dart';
import 'package:soul_saver/core/app_export.dart';
import 'package:soul_saver/widgets/app_bar/appbar_image.dart';
import 'package:soul_saver/widgets/app_bar/custom_app_bar.dart';
import 'package:flutter/material.dart';

class ProfileScreen extends GetWidget<ProfileController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: Container(
                height: size.height,
                width: double.maxFinite,
                child: Stack(alignment: Alignment.center, children: [
                  Align(
                      alignment: Alignment.bottomCenter,
                      child: Container(
                          padding: getPadding(left: 33, right: 33),
                          decoration: AppDecoration.outlineDeeporange100,
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Container(
                                    height: getVerticalSize(2),
                                    width: getHorizontalSize(31),
                                    decoration: BoxDecoration(
                                        color: ColorConstant.red800)),
                                Padding(
                                    padding:
                                        getPadding(left: 4, top: 2, right: 10),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          CustomImageView(
                                              svgPath: ImageConstant.imgHome,
                                              height: getVerticalSize(16),
                                              width: getHorizontalSize(15),
                                              onTap: () {
                                                onTapImgHome();
                                              }),
                                          Spacer(flex: 54),
                                          CustomImageView(
                                              svgPath: ImageConstant.imgMenu,
                                              height: getVerticalSize(16),
                                              width: getHorizontalSize(15)),
                                          Spacer(flex: 45),
                                          CustomImageView(
                                              svgPath:
                                                  ImageConstant.imgUserRed800,
                                              height: getVerticalSize(16),
                                              width: getHorizontalSize(15))
                                        ])),
                                Padding(
                                    padding: getPadding(
                                        top: 2, right: 6, bottom: 61),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          Padding(
                                              padding: getPadding(top: 2),
                                              child: Text("lbl_home".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtMontserratSemiBold8)),
                                          Spacer(flex: 55),
                                          Padding(
                                              padding: getPadding(bottom: 2),
                                              child: Text(
                                                  "lbl_notifications".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtMontserratRegular8)),
                                          Spacer(flex: 44),
                                          Padding(
                                              padding: getPadding(bottom: 2),
                                              child: Text("lbl_profile".tr,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  textAlign: TextAlign.left,
                                                  style: AppStyle
                                                      .txtMontserratRegular8Red800))
                                        ]))
                              ]))),
                  Align(
                      alignment: Alignment.center,
                      child: Container(
                          decoration: AppDecoration.fillRed800,
                          child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                CustomAppBar(
                                    height: getVerticalSize(60),
                                    leadingWidth: 46,
                                    leading: AppbarImage(
                                        height: getVerticalSize(13),
                                        width: getHorizontalSize(9),
                                        svgPath:
                                            ImageConstant.imgArrowleftWhiteA700,
                                        margin: getMargin(
                                            left: 37, top: 7, bottom: 4),
                                        onTap: onTapArrowleft1),
                                    title: Padding(
                                        padding: getPadding(left: 16),
                                        child: Text("lbl_profile".tr,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.left,
                                            style: AppStyle
                                                .txtMontserratBold20WhiteA700))),
                                Container(
                                    height: getVerticalSize(751),
                                    width: double.maxFinite,
                                    child: Stack(
                                        alignment: Alignment.topCenter,
                                        children: [
                                          Align(
                                              alignment: Alignment.center,
                                              child: Container(
                                                  margin: getMargin(top: 32),
                                                  padding: getPadding(
                                                      left: 13,
                                                      top: 91,
                                                      right: 13,
                                                      bottom: 91),
                                                  decoration: AppDecoration
                                                      .fillWhiteA700
                                                      .copyWith(
                                                          borderRadius:
                                                              BorderRadiusStyle
                                                                  .customBorderTL30),
                                                  child: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Container(
                                                            margin: getMargin(
                                                                left: 1,
                                                                top: 26,
                                                                right: 5),
                                                            padding: getPadding(
                                                                left: 7,
                                                                top: 5,
                                                                right: 7,
                                                                bottom: 5),
                                                            decoration:
                                                                AppDecoration
                                                                    .fillBluegray100,
                                                            child: Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .center,
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .min,
                                                                children: [
                                                                  CustomImageView(
                                                                      svgPath: ImageConstant
                                                                          .imgUser,
                                                                      height:
                                                                          getVerticalSize(
                                                                              20),
                                                                      width:
                                                                          getHorizontalSize(
                                                                              22),
                                                                      margin: getMargin(
                                                                          left:
                                                                              2,
                                                                          top:
                                                                              2,
                                                                          bottom:
                                                                              2)),
                                                                  Padding(
                                                                      padding: getPadding(
                                                                          left:
                                                                              17,
                                                                          top:
                                                                              4),
                                                                      child: RichText(
                                                                          text: TextSpan(children: [
                                                                            TextSpan(
                                                                                text: "lbl_my".tr,
                                                                                style: TextStyle(color: ColorConstant.fromHex("#181d27"), fontSize: getFontSize(15), fontFamily: 'DM Sans', fontWeight: FontWeight.w500)),
                                                                            TextSpan(
                                                                                text: "lbl_account".tr,
                                                                                style: TextStyle(color: ColorConstant.fromHex("#181d27"), fontSize: getFontSize(15), fontFamily: 'Poppins', fontWeight: FontWeight.w500)),
                                                                            TextSpan(
                                                                                text: " ",
                                                                                style: TextStyle(color: ColorConstant.fromHex("#181d27"), fontSize: getFontSize(15), fontFamily: 'DM Sans', fontWeight: FontWeight.w500))
                                                                          ]),
                                                                          textAlign: TextAlign.left)),
                                                                  Spacer(),
                                                                  CustomImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgArrowright,
                                                                      height:
                                                                          getVerticalSize(
                                                                              11),
                                                                      width:
                                                                          getHorizontalSize(
                                                                              7),
                                                                      margin: getMargin(
                                                                          top:
                                                                              6,
                                                                          bottom:
                                                                              6))
                                                                ])),
                                                        Container(
                                                            margin: getMargin(
                                                                left: 1,
                                                                top: 36,
                                                                right: 5),
                                                            padding: getPadding(
                                                                left: 7,
                                                                top: 5,
                                                                right: 7,
                                                                bottom: 5),
                                                            decoration:
                                                                AppDecoration
                                                                    .fillBluegray100,
                                                            child: Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .center,
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .min,
                                                                children: [
                                                                  CustomImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgUmoon,
                                                                      height:
                                                                          getSize(
                                                                              24),
                                                                      width:
                                                                          getSize(
                                                                              24),
                                                                      margin: getMargin(
                                                                          left:
                                                                              2)),
                                                                  Padding(
                                                                      padding: getPadding(
                                                                          left:
                                                                              14,
                                                                          top:
                                                                              1),
                                                                      child: Text(
                                                                          "lbl_darkmode"
                                                                              .tr,
                                                                          overflow: TextOverflow
                                                                              .ellipsis,
                                                                          textAlign: TextAlign
                                                                              .left,
                                                                          style:
                                                                              AppStyle.txtPoppinsMedium15)),
                                                                  Spacer(),
                                                                  CustomImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgArrowright,
                                                                      height:
                                                                          getVerticalSize(
                                                                              11),
                                                                      width:
                                                                          getHorizontalSize(
                                                                              7),
                                                                      margin: getMargin(
                                                                          top:
                                                                              6,
                                                                          bottom:
                                                                              6))
                                                                ])),
                                                        Container(
                                                            margin: getMargin(
                                                                left: 1,
                                                                top: 36,
                                                                right: 5),
                                                            padding: getPadding(
                                                                left: 7,
                                                                top: 4,
                                                                right: 7,
                                                                bottom: 4),
                                                            decoration:
                                                                AppDecoration
                                                                    .fillBluegray100,
                                                            child: Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .end,
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .end,
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .min,
                                                                children: [
                                                                  CustomImageView(
                                                                      svgPath: ImageConstant
                                                                          .imgCut,
                                                                      height:
                                                                          getSize(
                                                                              22),
                                                                      width:
                                                                          getSize(
                                                                              22),
                                                                      margin: getMargin(
                                                                          left:
                                                                              5,
                                                                          top:
                                                                              6)),
                                                                  Padding(
                                                                      padding: getPadding(
                                                                          left:
                                                                              13,
                                                                          top:
                                                                              4),
                                                                      child: Text(
                                                                          "lbl_language"
                                                                              .tr,
                                                                          overflow: TextOverflow
                                                                              .ellipsis,
                                                                          textAlign: TextAlign
                                                                              .left,
                                                                          style:
                                                                              AppStyle.txtPoppinsMedium15)),
                                                                  Spacer(),
                                                                  CustomImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgArrowright,
                                                                      height:
                                                                          getVerticalSize(
                                                                              11),
                                                                      width:
                                                                          getHorizontalSize(
                                                                              7),
                                                                      margin: getMargin(
                                                                          top:
                                                                              8,
                                                                          bottom:
                                                                              8))
                                                                ])),
                                                        Container(
                                                            margin: getMargin(
                                                                left: 1,
                                                                top: 46,
                                                                right: 5),
                                                            padding: getPadding(
                                                                left: 2,
                                                                top: 5,
                                                                right: 2,
                                                                bottom: 5),
                                                            decoration:
                                                                AppDecoration
                                                                    .fillBluegray100,
                                                            child: Row(
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .min,
                                                                children: [
                                                                  CustomImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgLightbulb,
                                                                      height:
                                                                          getVerticalSize(
                                                                              20),
                                                                      width:
                                                                          getHorizontalSize(
                                                                              22),
                                                                      margin: getMargin(
                                                                          top:
                                                                              2,
                                                                          bottom:
                                                                              2)),
                                                                  Padding(
                                                                      padding: getPadding(
                                                                          left:
                                                                              17,
                                                                          top:
                                                                              2),
                                                                      child: Text(
                                                                          "lbl_help_support"
                                                                              .tr,
                                                                          overflow: TextOverflow
                                                                              .ellipsis,
                                                                          textAlign: TextAlign
                                                                              .left,
                                                                          style:
                                                                              AppStyle.txtPoppinsMedium15Gray90001)),
                                                                  Spacer(),
                                                                  CustomImageView(
                                                                      svgPath: ImageConstant
                                                                          .imgArrowright,
                                                                      height:
                                                                          getVerticalSize(
                                                                              11),
                                                                      width:
                                                                          getHorizontalSize(
                                                                              7),
                                                                      margin: getMargin(
                                                                          top:
                                                                              6,
                                                                          right:
                                                                              5,
                                                                          bottom:
                                                                              7))
                                                                ])),
                                                        Container(
                                                            margin: getMargin(
                                                                top: 27,
                                                                right: 6),
                                                            padding: getPadding(
                                                                left: 7,
                                                                top: 3,
                                                                right: 7,
                                                                bottom: 3),
                                                            decoration:
                                                                AppDecoration
                                                                    .fillBluegray100,
                                                            child: Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .center,
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .min,
                                                                children: [
                                                                  CustomImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgSignal,
                                                                      height:
                                                                          getVerticalSize(
                                                                              20),
                                                                      width:
                                                                          getHorizontalSize(
                                                                              22),
                                                                      margin: getMargin(
                                                                          top:
                                                                              4,
                                                                          bottom:
                                                                              4)),
                                                                  GestureDetector(
                                                                    onTap: () {
                                                                      // Navigate to the other screen
                                                                      Navigator.push(
                                                                        context,
                                                                        MaterialPageRoute(builder: (context) => AboutAppPage()),
                                                                      );
                                                                    },
                                                                    child: Padding(
                                                                      padding: getPadding(left: 18, top: 6),
                                                                      child: Text(
                                                                        "lbl_about_app".tr,
                                                                        overflow: TextOverflow.ellipsis,
                                                                        textAlign: TextAlign.left,
                                                                        style: AppStyle.txtPoppinsMedium15Gray90001,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Spacer(),
                                                                  CustomImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgArrowright,
                                                                      height:
                                                                          getVerticalSize(
                                                                              11),
                                                                      width:
                                                                          getHorizontalSize(
                                                                              7),
                                                                      margin: getMargin(
                                                                          top:
                                                                              8,
                                                                          bottom:
                                                                              9))
                                                                ])),
                                                        Spacer(),
                                                        Container(
                                                            margin: getMargin(
                                                                left: 1,
                                                                right: 5),
                                                            padding: getPadding(
                                                                left: 7,
                                                                top: 4,
                                                                right: 7,
                                                                bottom: 4),
                                                            decoration:
                                                                AppDecoration
                                                                    .fillBluegray100,
                                                            child: Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .center,
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .min,
                                                                children: [
                                                                  CustomImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgArrowleft,
                                                                      height:
                                                                          getVerticalSize(
                                                                              21),
                                                                      width:
                                                                          getHorizontalSize(
                                                                              20),
                                                                      margin: getMargin(
                                                                          top:
                                                                              3,
                                                                          bottom:
                                                                              2)),
                                                                  GestureDetector(
                                                                    onTap: () {
                                                                      // Navigate to the other screen
                                                                      Navigator.push(
                                                                        context,
                                                                        MaterialPageRoute(builder: (context) => LogInScreen()),
                                                                      );
                                                                    },
                                                                    child:Padding(
                                                                      padding: getPadding(
                                                                          left:
                                                                              15,
                                                                          top:
                                                                              3),
                                                                      child: Text(
                                                                          "lbl_log_out"
                                                                              .tr,
                                                                          overflow: TextOverflow
                                                                              .ellipsis,
                                                                          textAlign: TextAlign
                                                                              .left,
                                                                          style:
                                                                              AppStyle.txtPoppinsMedium15)),),
                                                                  Spacer(),
                                                                  CustomImageView(
                                                                      svgPath:
                                                                          ImageConstant
                                                                              .imgArrowright,
                                                                      height:
                                                                          getVerticalSize(
                                                                              11),
                                                                      width:
                                                                          getHorizontalSize(
                                                                              7),
                                                                      margin: getMargin(
                                                                          top:
                                                                              7,
                                                                          bottom:
                                                                              7))
                                                                ]))
                                                      ]))),
                                          CustomImageView(
                                              svgPath: ImageConstant.imgProfile,
                                              height: getSize(122),
                                              width: getSize(122),
                                              alignment: Alignment.topCenter)
                                        ]))
                              ])))
                ]))));
  }

  onTapImgHome() {
    Get.toNamed(AppRoutes.homePageScreen);
  }

  onTapArrowleft1() {
    Get.toNamed(AppRoutes.homePageScreen);
  }
}
