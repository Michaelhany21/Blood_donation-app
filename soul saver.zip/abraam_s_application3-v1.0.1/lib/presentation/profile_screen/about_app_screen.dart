import 'package:flutter/material.dart';

class AboutAppPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('About App'),
        backgroundColor: Colors.red,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Soul Saver',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.red,
              ),
            ),
            SizedBox(height: 16),
            Text(
              'Version 1.0.0',
              style: TextStyle(
                fontSize: 16,
                color: Colors.red,
              ),
            ),
            SizedBox(height: 16),
            Text(
              'Description:',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.red,
              ),
            ),
            SizedBox(height: 8),
            Text(
              'During this era, everything around us became computerized especially in our generation'
                  'that facilitate every problem by a blink of an eye. By facing the problem that in Egypt '
                  'around 1% of people only that donate yearly according to 2017 surveys.'
                  'So, we aim to encourage people to increase this percentage in the upcoming years to '
                  'save more people from suffering.',
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 16),
            Text(
              'Developer:',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.red,
              ),
            ),
            SizedBox(height: 8),
            Text(
              'Abram Maher',
              style: TextStyle(fontSize: 16),
            ),
            Text(
              'Ahmed Abdelnasser',
              style: TextStyle(fontSize: 16),
            ),
            Text(
              'Marianne Magdy',
              style: TextStyle(fontSize: 16),
            ),
            Text(
              'Michael Hany',
              style: TextStyle(fontSize: 16),
            ),



          ],
        ),
      ),
    );
  }
}
