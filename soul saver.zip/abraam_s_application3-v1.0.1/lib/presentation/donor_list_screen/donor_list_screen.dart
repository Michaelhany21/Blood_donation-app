import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../../core/utils/color_constant.dart';
import '../../core/utils/image_constant.dart';
import '../../core/utils/size_utils.dart';
import '../../widgets/app_bar/appbar_image.dart';
import '../../widgets/app_bar/appbar_title.dart';
import '../../widgets/app_bar/custom_app_bar.dart';

class DonorListScreen extends StatefulWidget {
  @override
  _DonorListScreenState createState() => _DonorListScreenState();
}

class _DonorListScreenState extends State<DonorListScreen> {
  List donors = [];
  CollectionReference collRef =
  FirebaseFirestore.instance.collection('Donate_Requests');

  void getData() async {
    var responsebody = await collRef.get();
    responsebody.docs.forEach((element) {
      setState(() {
        donors.add(element.data());
      });
    });
  }

  @override
  void initState() {
    super.initState();
    getData();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.red800,
        appBar: CustomAppBar(
          height: getVerticalSize(60),
          leadingWidth: 39,
          leading: AppbarImage(
            height: getVerticalSize(11),
            width: getHorizontalSize(7),
            svgPath: ImageConstant.imgArrowleftWhiteA700,
            margin: getMargin(left: 32, top: 24, bottom: 20),
            onTap: onTapArrowleft4,
          ),
          title: AppbarTitle(
            text: "lbl_donor_s_list2".tr,
            margin: getMargin(left: 14),
          ),
        ),
        body: donors.isEmpty || donors == null
            ? Center(child: CircularProgressIndicator())
            : ListView.builder(
          itemCount: donors.length,
          itemBuilder: (context, i) {
            final donor = donors[i];

            final name = donor['name'] ?? 'N/A';
            final number = donor['number'] ?? 'N/A';
            final blood = donor['blood'] ?? 'N/A';

            return Container(
              margin: EdgeInsets.symmetric(
                horizontal: 16.0,
                vertical: 8.0,
              ),
              padding: EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(8.0),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Name:",
                    style: TextStyle(
                      fontSize: 18.0,
                      fontWeight: FontWeight.bold,
                      color: Colors.red[800],
                    ),
                  ),
                  SizedBox(height: 4.0),
                  Text(
                    name,
                    style: TextStyle(
                      fontSize: 16.0,
                      color: Colors.black,
                    ),
                  ),
                  SizedBox(height: 8.0),
                  Text(
                    "Number:",
                    style: TextStyle(
                      fontSize: 18.0,
                      fontWeight: FontWeight.bold,
                      color: Colors.red[800],
                    ),
                  ),
                  SizedBox(height: 4.0),
                  Text(
                    number,
                    style: TextStyle(
                      fontSize: 16.0,
                      color: Colors.black,
                    ),
                  ),
                  SizedBox(height: 8.0),
                  Text(
                    "Blood Type:",
                    style: TextStyle(
                      fontSize: 18.0,
                      fontWeight: FontWeight.bold,
                      color: Colors.red[800],
                    ),
                  ),
                  SizedBox(height: 4.0),
                  Text(
                    blood,
                    style: TextStyle(
                      fontSize: 16.0,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  void onTapArrowleft4() {
    Get.back();
  }
}
