import 'package:get/get.dart';

class DonorlistItemModel {
  Rx<String> wunmitundeTxt = Rx("lbl_wunmi_tunde".tr);

  Rx<String> asTxt = Rx("lbl_as".tr);

  Rx<String> abTxt = Rx("lbl_ab".tr);

  String? id = "";
}
