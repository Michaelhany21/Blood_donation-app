import 'package:get/get.dart';
import 'donorlist_item_model.dart';

class DonorListModel {
  RxList<DonorlistItemModel> donorlistItemList =
      RxList.generate(7, (index) => DonorlistItemModel());
}
