import 'package:soul_saver/core/app_export.dart';
import 'package:soul_saver/presentation/donor_list_screen/models/donor_list_model.dart';

class DonorListController extends GetxController {
  Rx<DonorListModel> donorListModelObj = DonorListModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
