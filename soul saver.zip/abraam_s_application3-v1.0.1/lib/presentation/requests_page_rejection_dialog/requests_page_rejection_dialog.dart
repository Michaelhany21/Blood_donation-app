import 'controller/requests_page_rejection_controller.dart';
import 'package:soul_saver/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class RequestsPageRejectionDialog extends StatelessWidget {
  RequestsPageRejectionDialog(this.controller);

  RequestsPageRejectionController controller;

  @override
  Widget build(BuildContext context) {
    return Container(
        width: getHorizontalSize(282),
        padding: getPadding(left: 78, top: 34, right: 78, bottom: 34),
        decoration: AppDecoration.fillWhiteA700,
        child: Column(mainAxisAlignment: MainAxisAlignment.start, children: [
          Container(
              height: getVerticalSize(115),
              width: getHorizontalSize(119),
              child: Stack(alignment: Alignment.center, children: [
                CustomImageView(
                    svgPath: ImageConstant.imgClose,
                    height: getSize(50),
                    width: getSize(50),
                    alignment: Alignment.center,
                    onTap: () {
                      onTapImgClose();
                    }),
                Align(
                    alignment: Alignment.center,
                    child: Container(
                        height: getVerticalSize(115),
                        width: getHorizontalSize(119),
                        decoration: BoxDecoration(
                            borderRadius:
                                BorderRadius.circular(getHorizontalSize(59)),
                            border: Border.all(
                                color: ColorConstant.red800,
                                width: getHorizontalSize(10)))))
              ])),
          Padding(
              padding: getPadding(top: 20, bottom: 16),
              child: Text("lbl_you_rejected".tr,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.left,
                  style: AppStyle.txtMontserratBold18))
        ]));
  }

  onTapImgClose() {
    Get.back();
  }
}
