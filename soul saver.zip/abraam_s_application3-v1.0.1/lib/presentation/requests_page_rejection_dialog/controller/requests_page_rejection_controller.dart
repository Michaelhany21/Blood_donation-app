import 'package:soul_saver/core/app_export.dart';
import 'package:soul_saver/presentation/requests_page_rejection_dialog/models/requests_page_rejection_model.dart';

class RequestsPageRejectionController extends GetxController {
  Rx<RequestsPageRejectionModel> requestsPageRejectionModelObj =
      RequestsPageRejectionModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
