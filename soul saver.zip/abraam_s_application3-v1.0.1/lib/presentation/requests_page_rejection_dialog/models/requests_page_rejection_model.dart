class RequestsPageRejectionModel {}
