// ignore_for_file: unused_import, unused_local_variable

import 'package:soul_saver/presentation/home_page_screen/home_page_screen.dart';
import 'package:soul_saver/presentation/request_donation_sent_container_screen/request_donation_sent_container_screen.dart';
import 'package:soul_saver/presentation/request_donation_sent_page/request_donation_sent_page.dart';
import 'package:soul_saver/presentation/requests_page_accepting_screen/binding/requests_page_accepting_binding.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:soul_saver/presentation/sign_up_screen/sign_up_screen.dart';
import 'controller/donor_detail_controller.dart';
import 'package:soul_saver/core/app_export.dart';
import 'package:soul_saver/core/utils/validation_functions.dart';
import 'package:soul_saver/widgets/app_bar/appbar_image.dart';
import 'package:soul_saver/widgets/app_bar/custom_app_bar.dart';
import 'package:soul_saver/widgets/custom_drop_down.dart';
import 'package:soul_saver/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';


// ignore_for_file: must_be_immutable
class DonorDetailScreen extends GetWidget<DonorDetailController> {
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  User? user;
  Future<void> initUser() async {
    final userdata = FirebaseAuth.instance.currentUser;
    // ignore: avoid_print
    print(userdata?.uid);
    // ignore: avoid_print
    print(userdata?.email);
    // ignore: avoid_print
    print(userdata?.displayName);
    // ignore: avoid_print


  }
  final nameController = TextEditingController();
  final numberController = TextEditingController();
  final addressController = TextEditingController();
  final bloodController = TextEditingController();
  final dateController = TextEditingController();
  final genderController = TextEditingController();
  final heightController = TextEditingController();
  final weightController = TextEditingController();
  final ailmentController = TextEditingController();



  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            backgroundColor: ColorConstant.red800,
            appBar: CustomAppBar(
                height: getVerticalSize(50),
                leadingWidth: 33,
                leading: AppbarImage(
                    height: getVerticalSize(11),
                    width: getHorizontalSize(7),
                    svgPath: ImageConstant.imgArrowleftWhiteA700,
                    margin: getMargin(left: 26, top: 8, bottom: 5),
                    onTap: onTapArrowleft),
                title: Padding(
                    padding: getPadding(left: 14),
                    child: Text("lbl_detail".tr,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.left,
                        style: AppStyle.txtMontserratBold20))),
            body: Form(
                key: _formKey,
                child: SingleChildScrollView(
                    child: Padding(
                        padding: getPadding(top: 19),
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Padding(
                                  padding: getPadding(left: 13),
                                  child: Text("msg_please_enter_your".tr,
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.left,
                                      style: AppStyle.txtMontserratRegular13)),
                              Container(
                                  width: double.maxFinite,
                                  child: Container(
                                      padding: getPadding(all: 22),
                                      decoration: AppDecoration.fillGray50
                                          .copyWith(
                                              borderRadius: BorderRadiusStyle
                                                  .customBorderTL30),
                                      child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: [
                                            CustomTextFormField(
                                              controller: nameController,
                                                focusNode: FocusNode(),

                                                hintText: "lbl_name".tr,
                                                padding: TextFormFieldPadding
                                                    .PaddingT22,
                                                validator: (value) {
                                                  if (!isText(value)) {
                                                    return "Please enter valid text";
                                                  }
                                                  return null;
                                                }),
                                            CustomTextFormField(
                                                controller: numberController,
                                                focusNode: FocusNode(),

                                                hintText: "Number".tr,
                                                margin: getMargin(top: 37),
                                                padding: TextFormFieldPadding
                                                    .PaddingT22,
                                                validator: (value) {
                                                  if (!isText(value)) {
                                                    return "Please enter valid number";
                                                  }
                                                  return null;
                                                }),
                                            CustomTextFormField(
                                                focusNode: FocusNode(),
                                                controller: addressController,

                                                hintText: "lbl_address".tr,
                                                margin: getMargin(top: 37),
                                                padding: TextFormFieldPadding
                                                    .PaddingT22),
                                            CustomTextFormField(
                                                focusNode: FocusNode(),
                                                controller: bloodController,

                                                hintText: "Blood Tybe".tr,
                                                margin: getMargin(top: 37),
                                                padding: TextFormFieldPadding
                                                    .PaddingT22),
                                            Padding(
                                                padding: getPadding(top: 37),
                                                child: Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceBetween,
                                                    children: [
                                                      CustomTextFormField(
                                                          width:
                                                              getHorizontalSize(
                                                                  135),
                                                          focusNode:
                                                              FocusNode(),
                                                          controller: dateController,

                                                          hintText:
                                                              "lbl_date_of_birth"
                                                                  .tr,
                                                          padding:
                                                              TextFormFieldPadding
                                                                  .PaddingT22),
                                                      CustomTextFormField(
                                                          width:
                                                          getHorizontalSize(
                                                              135),
                                                          focusNode:
                                                          FocusNode(),
                                                          controller: genderController,

                                                          hintText:
                                                          "Gender"
                                                              .tr,
                                                          padding:
                                                          TextFormFieldPadding
                                                              .PaddingT22),
                                                    ])),
                                            Padding(
                                                padding: getPadding(top: 34),
                                                child: Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceBetween,
                                                    children: [
                                                      CustomTextFormField(
                                                          width:
                                                              getHorizontalSize(
                                                                  135),
                                                          focusNode:
                                                              FocusNode(),
                                                          controller: heightController,

                                                          hintText:
                                                              "lbl_height".tr,
                                                          padding:
                                                              TextFormFieldPadding
                                                                  .PaddingT22),
                                                      CustomTextFormField(
                                                          width:
                                                              getHorizontalSize(
                                                                  135),
                                                          focusNode:
                                                              FocusNode(),
                                                          controller: weightController,

                                                          hintText:
                                                              "lbl_weight".tr,
                                                          padding:
                                                              TextFormFieldPadding
                                                                  .PaddingT22)
                                                    ])),
                                            Container(
                                                height: getVerticalSize(60),
                                                width: getHorizontalSize(331),
                                                margin: getMargin(top: 37),
                                                child: Stack(
                                                    alignment: Alignment.center,
                                                    children: [
                                                      Align(
                                                          alignment: Alignment
                                                              .bottomLeft,
                                                          child: Padding(
                                                              padding:
                                                                  getPadding(
                                                                      left: 11,
                                                                      bottom:
                                                                          17),
                                                              child: Text(
                                                                  "msg_do_you_have_any"
                                                                      .tr,
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .left,
                                                                  style: AppStyle
                                                                      .txtMontserratRegular12))),

                                                    ])),
                                            CustomTextFormField(
                                                focusNode: FocusNode(),
                                                controller: ailmentController,

                                                hintText:
                                                    "msg_if_yes_please_state"
                                                        .tr,
                                                margin: getMargin(top: 37),
                                                padding: TextFormFieldPadding
                                                    .PaddingT22),
                                            ElevatedButton(
                                              onPressed: () async {
                                                CollectionReference collRef =
                                                FirebaseFirestore.instance.collection('Donate_Requests');
                                                collRef.add({
                                                  'name': nameController.text,
                                                  'number': numberController.text,
                                                  'address': addressController.text,
                                                  'blood': bloodController.text,
                                                  'date': dateController.text,
                                                  'gender': genderController.text,
                                                  'height': heightController.text,
                                                  'weight': weightController.text,
                                                  'ailment': ailmentController.text,


                                                });

                                                Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                    builder: (context) => HomePageScreen(),
                                                  ),
                                                );

                                              },
                                              style: ElevatedButton.styleFrom(
                                                primary: Colors.red[
                                                800], // Customize the button color
                                                padding: EdgeInsets.symmetric(
                                                    vertical: 15,
                                                    horizontal:
                                                    20), // Adjust the padding as needed
                                              ),
                                              child: Text(
                                                "lbl_enter".tr,
                                                style: TextStyle(
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 14,
                                                ),
                                              ),

                                            )
                                          ])))
                            ]))))));
  }

  onTapArrowleft() {
    Get.back();

  }

  // Future CreateUser(
  //     {required String name,
  //     required String address,
  //     required int height, required int weight, required String birth })
  //     async {
  //   final donate = FirebaseFirestore.instance.collection('DonateType').doc();
  //   final json = {
  //     'Name': name,
  //     'Address': address,
  //     'Blood Group': controller.donorDetailModelObj.value,
  //     'Date of Birth': birth,
  //     'Gender': controller.donorDetailModelObj.value,
  //     'Height': height,
  //     'Weight': weight,
  //     'Ailment': controller.ailmentdetailsController.text,
  //     'UserId': FirebaseAuth.instance.currentUser?.uid,
  //
  //   };
  //
  //   /*  if (mytitle.isEmpty) {
  //     Navigator.of(context).canPop();
  //   } else {
  //     Navigator.of(context).push(MaterialPageRoute(builder: (_) => Savetext()));
  //   }*/
  //
  //   print(user?.uid);
  //   print(user?.displayName);
  //   print(name);
  //   print(height);
  //   print(weight);
  //   await donate.set(json);
  // }
}
