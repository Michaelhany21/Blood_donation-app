import 'package:soul_saver/core/app_export.dart';
import 'package:soul_saver/presentation/donor_detail_screen/models/donor_detail_model.dart';
import 'package:flutter/material.dart';


class DonorDetailController extends GetxController {
  TextEditingController nameController = TextEditingController();

  TextEditingController addressController = TextEditingController();

  TextEditingController dateofbirthController = TextEditingController();

  TextEditingController weightController = TextEditingController();

  TextEditingController weightOneController = TextEditingController();

  TextEditingController ailmentdetailsController = TextEditingController();

  TextEditingController submitController = TextEditingController();

  Rx<DonorDetailModel> donorDetailModelObj = DonorDetailModel().obs;

  SelectionPopupModel? selectedDropDownValue;

  SelectionPopupModel? selectedDropDownValue1;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
    nameController.dispose();
    addressController.dispose();
    dateofbirthController.dispose();
    weightController.dispose();
    weightOneController.dispose();
    ailmentdetailsController.dispose();
    submitController.dispose();
  }

  onSelected(dynamic value) {
    selectedDropDownValue = value as SelectionPopupModel;
    donorDetailModelObj.value.dropdownItemList.forEach((element) {
      element.isSelected = false;
      if (element.id == value.id) {
        element.isSelected = true;
      }
    });
    donorDetailModelObj.value.dropdownItemList.refresh();
  }

  onSelected1(dynamic value) {
    selectedDropDownValue1 = value as SelectionPopupModel;
    donorDetailModelObj.value.dropdownItemList1.forEach((element) {
      element.isSelected = false;
      if (element.id == value.id) {
        element.isSelected = true;
      }
    });
    donorDetailModelObj.value.dropdownItemList1.refresh();
  }
}
