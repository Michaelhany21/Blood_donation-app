import 'package:get/get.dart';
import 'package:soul_saver/data/models/selectionPopupModel/selection_popup_model.dart';

class DonorDetailModel {
  RxList<SelectionPopupModel> dropdownItemList = [
    SelectionPopupModel(
      id: 1,
      title: "A+",
      isSelected: true, text: '',
    ),
    SelectionPopupModel(
      id: 2,
      title: "A-", text: '',
    ),
    SelectionPopupModel(
      id: 2,
      title: "B+", text: '',
    ),
    SelectionPopupModel(
      id: 2,
      title: "B-", text: '',
    ),
    SelectionPopupModel(
      id: 2,
      title: "AB+", text: '',
    ),
    SelectionPopupModel(
      id: 2,
      title: "AB-", text: '',
    ),
    SelectionPopupModel(
      id: 2,
      title: "O+", text: '',
    ),

    SelectionPopupModel(
      id: 3,
      title: "O-", text: '',
    )
  ].obs;

  RxList<SelectionPopupModel> dropdownItemList1 = [
    SelectionPopupModel(
      id: 1,
      title: "Male",
      isSelected: true, text: '',
    ),
    SelectionPopupModel(
      id: 2,
      title: "Female", text: '',
    ),
  ].obs;
}
