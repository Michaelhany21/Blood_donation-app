class NotificationsModel {}
