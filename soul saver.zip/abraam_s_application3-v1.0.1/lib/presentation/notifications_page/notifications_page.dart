import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../core/utils/image_constant.dart';
import '../../core/utils/size_utils.dart';
import '../../widgets/app_bar/appbar_image.dart';
import '../../widgets/app_bar/appbar_title.dart';
import '../../widgets/app_bar/custom_app_bar.dart';

class NotificationsPage extends StatefulWidget {
  @override
  _NotificationsPageState createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<NotificationsPage> {
  List<Map<String, dynamic>> requests = [];
  CollectionReference collRef =
  FirebaseFirestore.instance.collection('Requests');

  Stream<QuerySnapshot<Object?>> getRequestsStream() {
    return collRef.snapshots();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.red[800],
        appBar: CustomAppBar(
          height: getVerticalSize(60),
          leadingWidth: 39,
          leading: AppbarImage(
            height: getVerticalSize(11),
            width: getHorizontalSize(7),
            svgPath: ImageConstant.imgArrowleftWhiteA700,
            margin: getMargin(left: 32, top: 24, bottom: 20),
            onTap: onTapArrowleft4,
          ),
          title: AppbarTitle(
            text: "Notification".tr,
            margin: getMargin(left: 14),
          ),
        ),
        body: StreamBuilder<QuerySnapshot<Object?>>(
          stream: getRequestsStream(),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              requests = snapshot.data?.docs.map((doc) => doc.data() as Map<String, dynamic>).toList() ?? [];
              return ListView.builder(
                itemCount: requests.length,
                itemBuilder: (context, index) {
                  final request = requests[index];
                  final institutionName = request['institutionName'] ?? 'N/A';
                  final timeNeeded = request['timeNeeded'] ?? 'N/A';
                  final blood = request['bloodType'] ?? 'N/A';

                  return Container(
                    margin: EdgeInsets.symmetric(
                      horizontal: 16.0,
                      vertical: 8.0,
                    ),
                    padding: EdgeInsets.all(16.0),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Institution Name:",
                          style: TextStyle(
                            fontSize: 18.0,
                            fontWeight: FontWeight.bold,
                            color: Colors.red[800],
                          ),
                        ),
                        SizedBox(height: 4.0),
                        Text(
                          institutionName,
                          style: TextStyle(
                            fontSize: 16.0,
                            color: Colors.black,
                          ),
                        ),
                        SizedBox(height: 8.0),
                        Text(
                          "Time Needed:",
                          style: TextStyle(
                            fontSize: 18.0,
                            fontWeight: FontWeight.bold,
                            color: Colors.red[800],
                          ),
                        ),
                        SizedBox(height: 4.0),
                        Text(
                          timeNeeded,
                          style: TextStyle(
                            fontSize: 16.0,
                            color: Colors.black,
                          ),
                        ),
                        SizedBox(height: 8.0),
                        Text(
                          "Blood Type:",
                          style: TextStyle(
                            fontSize: 18.0,
                            fontWeight: FontWeight.bold,
                            color: Colors.red[800],
                          ),
                        ),
                        SizedBox(height: 4.0),
                        Text(
                          blood,
                          style: TextStyle(
                            fontSize: 16.0,
                            color: Colors.black,
                          ),
                        ),
                      ],
                    ),
                  );
                },
              );
            } else if (snapshot.hasError) {
              return Text('Error: ${snapshot.error}');
            } else {
              return CircularProgressIndicator();
            }
          },
        ),
      ),
    );
  }
  void onTapArrowleft4() {
    Get.back();
  }
}
