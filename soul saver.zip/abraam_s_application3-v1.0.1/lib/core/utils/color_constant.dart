import 'dart:ui';
import 'package:flutter/material.dart';

class ColorConstant {
  static Color gray600 = fromHex('#6c6b6b');

  static Color gray60002 = fromHex('#6c6c6c');

  static Color gray400 = fromHex('#c4c4c4');

  static Color deepOrange10093 = fromHex('#93f5c0c0');

  static Color gray500 = fromHex('#979494');

  static Color blueGray100 = fromHex('#d9d9d9');

  static Color gray60001 = fromHex('#7f7e7e');

  static Color gray800 = fromHex('#484848');

  static Color red800 = fromHex('#c62c2c');

  static Color gray900 = fromHex('#222222');

  static Color gray90001 = fromHex('#181d27');

  static Color gray200A0 = fromHex('#a0eaeaea');

  static Color black9003f = fromHex('#3f000000');

  static Color gray50 = fromHex('#f9f9f9');

  static Color greenA100A0 = fromHex('#a0c8f9c4');

  static Color red80001 = fromHex('#c52c2c');

  static Color black900 = fromHex('#000000');

  static Color bluegray400 = fromHex('#888888');

  static Color whiteA70001 = fromHex('#fffdfd');

  static Color gray40047 = fromHex('#47c4c4c4');

  static Color blueGray900 = fromHex('#2e2d2d');

  static Color whiteA700 = fromHex('#ffffff');

  static Color deepOrange100 = fromHex('#f5c0c0');

  static Color fromHex(String hexString) {
    final buffer = StringBuffer();
    if (hexString.length == 6 || hexString.length == 7) buffer.write('ff');
    buffer.write(hexString.replaceFirst('#', ''));
    return Color(int.parse(buffer.toString(), radix: 16));
  }
}
