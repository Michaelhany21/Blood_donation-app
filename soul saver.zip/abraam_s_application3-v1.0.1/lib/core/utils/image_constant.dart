class ImageConstant {
  static String imgQrcode = 'assets/images/img_qrcode.svg';

  static String imgLocationRed800 = 'assets/images/img_location_red_800.svg';

  static String imgVector = 'assets/images/img_vector.svg';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgArrowdown = 'assets/images/img_arrowdown.svg';

  static String imgProfileGray600 = 'assets/images/img_profile_gray_600.svg';

  static String imgClose = 'assets/images/img_close.svg';

  static String imgMusic = 'assets/images/img_music.svg';

  static String imgLock = 'assets/images/img_lock.svg';

  static String imgMenu = 'assets/images/img_menu.svg';

  static String imgSort = 'assets/images/img_sort.svg';

  static String imgClock = 'assets/images/img_clock.svg';

  static String imgFingerprint = 'assets/images/img_fingerprint.svg';

  static String imgArrowright = 'assets/images/img_arrowright.svg';

  static String imgUser = 'assets/images/img_user.svg';

  static String imgLightbulb = 'assets/images/img_lightbulb.svg';

  static String imgHomeGray60001 = 'assets/images/img_home_gray_600_01.svg';

  static String imgFreepikcharacter = 'assets/images/img_freepikcharacter.svg';

  static String imgHomeGray600015x20 =
      'assets/images/img_home_gray_600_01_5x20.svg';

  static String imgGooglemaps = 'assets/images/img_googlemaps.png';

  static String imgUserGray600 = 'assets/images/img_user_gray_600.svg';

  static String imgArrowleftWhiteA70015x9 =
      'assets/images/img_arrowleft_white_a700_15x9.svg';

  static String imgSignal = 'assets/images/img_signal.svg';

  static String imgVolume = 'assets/images/img_volume.svg';

  static String imgFile = 'assets/images/img_file.svg';

  static String imgCut = 'assets/images/img_cut.svg';

  static String imgHomeRed800 = 'assets/images/img_home_red_800.svg';

  static String imgLocation = 'assets/images/img_location.svg';

  static String imgMenuRed800 = 'assets/images/img_menu_red_800.svg';

  static String imgLockRed800 = 'assets/images/img_lock_red_800.svg';

  static String imgCheckmark = 'assets/images/img_checkmark.svg';

  static String imgProfile = 'assets/images/img_profile.svg';

  static String imgUmoon = 'assets/images/img_umoon.svg';

  static String imgNotifications = 'assets/images/img_notifications.svg';

  static String imgGroup49 = 'assets/images/img_group49.svg';

  static String imgMenuGray600 = 'assets/images/img_menu_gray_600.svg';

  static String imgEllipse24 = 'assets/images/img_ellipse24.png';

  static String imgHome = 'assets/images/img_home.svg';

  static String imgRectangle88stroke =
      'assets/images/img_rectangle88stroke.svg';

  static String imgArrowleftWhiteA700 =
      'assets/images/img_arrowleft_white_a700.svg';

  static String imgUserRed800 = 'assets/images/img_user_red_800.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
