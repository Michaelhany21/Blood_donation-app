// ignore_for_file: unused_import

import 'package:soul_saver/presentation/welcome_screen/welcome_screen.dart';
import 'package:soul_saver/presentation/welcome_screen/binding/welcome_binding.dart';
import 'package:soul_saver/presentation/donor_detail_screen/donor_detail_screen.dart';
import 'package:soul_saver/presentation/donor_detail_screen/binding/donor_detail_binding.dart';
import 'package:soul_saver/presentation/profile_screen/profile_screen.dart';
import 'package:soul_saver/presentation/profile_screen/binding/profile_binding.dart';
import 'package:soul_saver/presentation/home_page_screen/home_page_screen.dart';
import 'package:soul_saver/presentation/home_page_screen/binding/home_page_binding.dart';
import 'package:soul_saver/presentation/request_donation_sent_container_screen/request_donation_sent_container_screen.dart';
import 'package:soul_saver/presentation/request_donation_sent_container_screen/binding/request_donation_sent_container_binding.dart';
import 'package:soul_saver/presentation/log_in_screen/log_in_screen.dart';
import 'package:soul_saver/presentation/log_in_screen/binding/log_in_binding.dart';
import 'package:soul_saver/presentation/sign_up_screen/sign_up_screen.dart';
import 'package:soul_saver/presentation/sign_up_screen/binding/sign_up_binding.dart';
import 'package:soul_saver/presentation/google_maps_screen/google_maps_screen.dart';
import 'package:soul_saver/presentation/google_maps_screen/binding/google_maps_binding.dart';
import 'package:soul_saver/presentation/contact_donor_screen/contact_donor_screen.dart';
import 'package:soul_saver/presentation/contact_donor_screen/binding/contact_donor_binding.dart';
import 'package:soul_saver/presentation/donor_list_screen/donor_list_screen.dart';
import 'package:soul_saver/presentation/donor_list_screen/binding/donor_list_binding.dart';
import 'package:soul_saver/presentation/donation_centers_screen/donation_centers_screen.dart';
import 'package:soul_saver/presentation/donation_centers_screen/binding/donation_centers_binding.dart';
import 'package:soul_saver/presentation/requests_page_screen/requests_page_screen.dart';
import 'package:soul_saver/presentation/requests_page_screen/binding/requests_page_binding.dart';
import 'package:soul_saver/presentation/requests_page_accepting_screen/requests_page_accepting_screen.dart';
import 'package:soul_saver/presentation/requests_page_accepting_screen/binding/requests_page_accepting_binding.dart';
import 'package:soul_saver/presentation/app_navigation_screen/app_navigation_screen.dart';
import 'package:soul_saver/presentation/app_navigation_screen/binding/app_navigation_binding.dart';
import 'package:get/get.dart';

class AppRoutes {
  static const String welcomeScreen = '/welcome_screen';

  static const String donorDetailScreen = '/donor_detail_screen';

  static const String profileScreen = '/profile_screen';

  static const String homePageScreen = '/home_page_screen';

  static const String requestDonationSentContainerScreen =
      '/request_donation_sent_container_screen';

  static const String requestDonationSentPage = '/request_donation_sent_page';

  static const String logInScreen = '/log_in_screen';

  static const String signUpScreen = '/sign_up_screen';

  static const String googleMapsScreen = '/google_maps_screen';

  static const String contactDonorScreen = '/contact_donor_screen';

  static const String donorListScreen = '/donor_list_screen';

  static const String donationCentersScreen = '/donation_centers_screen';

  static const String notificationsPage = '/notifications_page';

  static const String requestsPageScreen = '/requests_page_screen';

  static const String requestsPageAcceptingScreen =
      '/requests_page_accepting_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static String initialRoute = '/initialRoute';

  static List<GetPage> pages = [
    GetPage(
      name: welcomeScreen,
      page: () => WelcomeScreen(),
      bindings: [
        WelcomeBinding(),
      ],
    ),
    GetPage(
      name: donorDetailScreen,
      page: () => DonorDetailScreen(),
      bindings: [
        DonorDetailBinding(),
      ],
    ),
    GetPage(
      name: profileScreen,
      page: () => ProfileScreen(),
      bindings: [
        ProfileBinding(),
      ],
    ),
    // GetPage(
    //   name: homePageScreen,
    //   page: () => homePageScreen,
    //   bindings: [
    //     HomePageBinding(),
    //   ],
    // ),
    GetPage(
      name: requestDonationSentContainerScreen,
      page: () => RequestDonationSentContainerScreen(),
      bindings: [
        RequestDonationSentContainerBinding(),
      ],
    ),
    GetPage(
      name: logInScreen,
      page: () => LogInScreen(),
      bindings: [
        LogInBinding(),
      ],
    ),
    GetPage(
      name: signUpScreen,
      page: () => SignUpScreen(),
      bindings: [
        SignUpBinding(),
      ],
    ),
    GetPage(
      name: googleMapsScreen,
      page: () => GoogleMapsScreen(),
      bindings: [
        GoogleMapsBinding(),
      ],
    ),
    GetPage(
      name: contactDonorScreen,
      page: () => ContactDonorScreen(),
      bindings: [
        ContactDonorBinding(),
      ],
    ),
    GetPage(
      name: donorListScreen,
      page: () => DonorListScreen(),
      bindings: [
        DonorListBinding(),
      ],
    ),
    GetPage(
      name: donationCentersScreen,
      page: () => DonationCentersScreen(),
      bindings: [
        DonationCentersBinding(),
      ],
    ),
    GetPage(
      name: requestsPageScreen,
      page: () => RequestsPageScreen(),
      bindings: [
        RequestsPageBinding(),
      ],
    ),
    GetPage(
      name: requestsPageAcceptingScreen,
      page: () => RequestsPageAcceptingScreen(),
      bindings: [
        RequestsPageAcceptingBinding(),
      ],
    ),
    GetPage(
      name: appNavigationScreen,
      page: () => AppNavigationScreen(),
      bindings: [
        AppNavigationBinding(),
      ],
    ),
    GetPage(
      name: initialRoute,
      page: () => WelcomeScreen(),
      bindings: [
        WelcomeBinding(),
      ],
    )
  ];
}
